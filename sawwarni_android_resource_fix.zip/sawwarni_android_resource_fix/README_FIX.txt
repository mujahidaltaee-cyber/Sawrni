Sawwarni Android resource-linking fix

This patch removes the invalid Android framework attribute:
android:postSplashScreenTheme

It also switches from Theme.Sawwarni.Launch to Theme.Sawwarni when MainActivity starts.

Copy the included android-app folder over the existing android-app folder, commit, and push.
