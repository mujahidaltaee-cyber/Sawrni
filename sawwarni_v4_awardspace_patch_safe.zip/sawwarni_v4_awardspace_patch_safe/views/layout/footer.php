<footer class="footer">
  <div class="container footer-grid">
    <div>
      <div class="footer-brand"><img class="footer-logo" src="assets/img/brand/logo-light.svg" alt="صورني"></div>
      <p>منصة عراقية متكاملة لحجز المصورين، الفيديو، الدرون، الاستوديو والمونتاج بثقة وأسعار واضحة.</p>
      <div class="pill-row" style="margin-top:14px"><span class="badge badge-gray">بغداد أولاً</span><span class="badge badge-gray">حجوزات موثقة</span></div>
    </div>
    <div>
      <strong>اكتشف</strong>
      <p><a href="<?= url('providers') ?>">المصورون والخدمات</a></p>
      <p><a href="<?= url('providers',['category_id'=>1]) ?>">جلسات التخرج</a></p>
      <p><a href="<?= url('providers',['category_id'=>3]) ?>">الدرون</a></p>
    </div>
    <div>
      <strong>لمقدمي الخدمة</strong>
      <p><a href="<?= url('register',['type'=>'provider']) ?>">إنشاء حساب مصور</a></p>
      <p><a href="<?= url('provider_login') ?>">دخول مقدم الخدمة</a></p>
      <p>عمولة الحجز: <?= e(setting('commission_percent', '10')) ?>%</p>
    </div>
    <div>
      <strong>الدعم</strong>
      <p>رسوم الحجز العاجل: <?= format_iqd(setting('urgent_fee', '10000')) ?></p>
      <p>الدفع اليدوي والتجريبي متاح</p>
      <p>دعم الحجوزات والشكاوى</p>
    </div>
  </div>
  <div class="container footer-bottom"><span>© <?= date('Y') ?> صورني — نسخة اختبار حقيقية PHP/MySQL</span><span>صُممت لتجربة رحلة العميل والمصور والإدارة</span></div>
</footer>
<?php if (($user['role'] ?? '') === 'customer'): ?>
<nav class="mobile-bottom-nav">
  <a class="<?= $currentPage==='home'?'active':'' ?>" href="<?= url('home') ?>"><b>⌂</b><span>الرئيسية</span></a>
  <a class="<?= $currentPage==='providers'?'active':'' ?>" href="<?= url('providers') ?>"><b>⌕</b><span>اكتشف</span></a>
  <a class="<?= $currentPage==='customer_dashboard'?'active':'' ?>" href="<?= url('customer_dashboard') ?>"><b>▣</b><span>حجوزاتي</span></a>
  <a class="<?= $currentPage==='customer_profile'?'active':'' ?>" href="<?= url('customer_profile') ?>"><b>◉</b><span>حسابي</span></a>
</nav>
<?php elseif (!$user): ?>
<nav class="mobile-bottom-nav">
  <a class="<?= $currentPage==='home'?'active':'' ?>" href="<?= url('home') ?>"><b>⌂</b><span>الرئيسية</span></a>
  <a class="<?= $currentPage==='providers'?'active':'' ?>" href="<?= url('providers') ?>"><b>⌕</b><span>المصورون</span></a>
  <a href="<?= url('customer_login') ?>"><b>◉</b><span>دخول</span></a>
  <a href="<?= url('register',['type'=>'customer']) ?>"><b>＋</b><span>حساب جديد</span></a>
</nav>
<?php endif; ?>
<script src="assets/js/app.js?v=4.0"></script>
</body>
</html>
