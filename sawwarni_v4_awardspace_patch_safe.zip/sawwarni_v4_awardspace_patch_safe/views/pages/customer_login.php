<?php $pageTitle = 'دخول العميل'; require APP_ROOT . '/views/layout/header.php'; ?>
<section class="auth-section"><div class="container auth-narrow"><div class="auth-layout">
  <div class="auth-visual"><img src="assets/img/demo/graduation.jpg" alt=""><div class="auth-brand"><img src="assets/img/brand/logo-light.svg" alt="صورني"></div><div><span class="badge badge-gray">واجهة العميل</span><h2>احجز لحظتك القادمة بثقة.</h2><p>قارن الأعمال والأسعار، تابع الطلب، وتواصل مع مقدم الخدمة من مكان واحد.</p></div></div>
  <div class="auth-form-panel"><span class="eyebrow">Customer login</span><h1 style="font-size:2.5rem;margin:.2rem 0">أهلاً بعودتك</h1><p class="muted">سجل الدخول لمتابعة حجوزاتك أو إرسال طلب جديد.</p>
    <form class="grid-form" method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="customer_login"><label>البريد الإلكتروني<div class="input-icon"><span>✉</span><input type="email" name="email" required autocomplete="email" value="customer@sawwarni.test"></div></label><label>كلمة المرور<div class="input-icon"><span>●</span><input type="password" name="password" required autocomplete="current-password" value="123456"></div></label><button class="btn customer-btn large block" type="submit">دخول العميل</button></form>
    <div class="auth-footer">ليس لديك حساب؟ <a href="<?= url('register',['type'=>'customer']) ?>">إنشاء حساب عميل</a></div><div class="divider"></div><a class="btn block" href="<?= url('provider_login') ?>">أنا مقدم خدمة</a>
  </div>
</div></div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
