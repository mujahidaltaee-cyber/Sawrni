# Install into the existing Sawrni GitHub repository

From the repository root in Codespaces:

```bash
cd /workspaces/Sawrni
unzip -o sawwarni_apk_github_ready.zip -d /workspaces/Sawrni
find android-app -maxdepth 2 -type f | sort
git add android-app .github/workflows/build-sawwarni-apk.yml
git commit -m "Add Sawwarni Android test app"
git push
```

Then open GitHub → Actions → Build Sawwarni APK → Run workflow.
