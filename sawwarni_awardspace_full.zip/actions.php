<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
require_method_post();
verify_csrf();

$action = $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'customer_login': {
            $email = strtolower(trim($_POST['email'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $user = fetch_one('SELECT * FROM users WHERE email = ? AND role = "customer"', [$email]);
            if (!$user || !password_verify($password, $user['password_hash'])) {
                flash('danger', 'البريد الإلكتروني أو كلمة المرور غير صحيحة.');
                redirect('customer_login');
            }
            if ($user['status'] !== 'active') {
                flash('danger', 'هذا الحساب غير مفعل حالياً.');
                redirect('customer_login');
            }
            login_user($user);
            execute_sql('UPDATE users SET last_login_at=NOW() WHERE id=?', [$user['id']]);
            log_audit('customer_login', 'user', (int)$user['id']);
            redirect('customer_dashboard');
        }

        case 'provider_login': {
            $email = strtolower(trim($_POST['email'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $user = fetch_one('SELECT * FROM users WHERE email = ? AND role = "provider"', [$email]);
            if (!$user || !password_verify($password, $user['password_hash'])) {
                flash('danger', 'البريد الإلكتروني أو كلمة المرور غير صحيحة.');
                redirect('provider_login');
            }
            if (in_array($user['status'], ['blocked', 'rejected'], true)) {
                flash('danger', 'الحساب موقوف أو مرفوض. تواصل مع الإدارة.');
                redirect('provider_login');
            }
            login_user($user);
            execute_sql('UPDATE users SET last_login_at=NOW() WHERE id=?', [$user['id']]);
            log_audit('provider_login', 'user', (int)$user['id']);
            redirect('provider_dashboard');
        }

        case 'management_login': {
            $username = trim($_POST['username'] ?? '');
            $password = (string)($_POST['password'] ?? '');
            $user = fetch_one('SELECT * FROM users WHERE username = ? AND role = "admin" AND status = "active"', [$username]);
            if (!$user || !password_verify($password, $user['password_hash'])) {
                flash('danger', 'بيانات الإدارة غير صحيحة.');
                redirect_raw('management.php');
            }
            login_user($user);
            execute_sql('UPDATE users SET last_login_at=NOW() WHERE id=?', [$user['id']]);
            log_audit('management_login', 'user', (int)$user['id']);
            redirect('admin_dashboard');
        }

        case 'register_customer': {
            $name = trim($_POST['name'] ?? '');
            $email = strtolower(trim($_POST['email'] ?? ''));
            $phone = trim($_POST['phone'] ?? '');
            $password = (string)($_POST['password'] ?? '');
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
                flash('danger', 'أدخل الاسم والبريد الصحيح وكلمة مرور من 6 أحرف على الأقل.');
                redirect('register', ['type' => 'customer']);
            }
            if (fetch_one('SELECT id FROM users WHERE email=?', [$email])) {
                flash('danger', 'البريد الإلكتروني مستخدم مسبقاً.');
                redirect('register', ['type' => 'customer']);
            }
            execute_sql('INSERT INTO users (name, email, phone, password_hash, role, status) VALUES (?, ?, ?, ?, "customer", "active")', [$name, $email, $phone, password_hash($password, PASSWORD_DEFAULT)]);
            $user = fetch_one('SELECT * FROM users WHERE id = ?', [last_insert_id()]);
            login_user($user);
            log_audit('register_customer', 'user', (int)$user['id']);
            flash('success', 'أهلاً بك في صورني. يمكنك الآن اختيار المصور وإرسال الحجز.');
            redirect('customer_dashboard');
        }

        case 'register_provider': {
            $name = trim($_POST['name'] ?? '');
            $email = strtolower(trim($_POST['email'] ?? ''));
            $phone = trim($_POST['phone'] ?? '');
            $password = (string)($_POST['password'] ?? '');
            $business = trim($_POST['business_name'] ?? '');
            $city = trim($_POST['city'] ?? 'بغداد');
            $instagram = trim($_POST['instagram_url'] ?? '');
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $business === '' || strlen($password) < 6) {
                flash('danger', 'أكمل معلومات مقدم الخدمة واستخدم كلمة مرور من 6 أحرف على الأقل.');
                redirect('register', ['type' => 'provider']);
            }
            if (fetch_one('SELECT id FROM users WHERE email=?', [$email])) {
                flash('danger', 'البريد الإلكتروني مستخدم مسبقاً.');
                redirect('register', ['type' => 'provider']);
            }
            db()->beginTransaction();
            execute_sql('INSERT INTO users (name, email, phone, password_hash, role, status) VALUES (?, ?, ?, ?, "provider", "pending")', [$name, $email, $phone, password_hash($password, PASSWORD_DEFAULT)]);
            $uid = (int) last_insert_id();
            execute_sql('INSERT INTO provider_profiles (user_id, business_name, city, instagram_url) VALUES (?, ?, ?, ?)', [$uid, $business, $city, $instagram]);
            db()->commit();
            flash('success', 'تم إنشاء حسابك. يمكنك تسجيل الدخول وتجهيز الملف، ويظهر للعامة بعد موافقة الإدارة.');
            redirect('provider_login');
        }

        case 'logout': {
            logout_user();
            redirect('home');
        }

        case 'customer_profile_save': {
            require_role('customer');
            $name = trim($_POST['name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            if ($name === '') throw new RuntimeException('الاسم مطلوب.');
            execute_sql('UPDATE users SET name=?, phone=? WHERE id=?', [$name, $phone, current_user()['id']]);
            flash('success', 'تم تحديث الملف الشخصي.');
            redirect('customer_profile');
        }

        case 'change_password': {
            require_auth();
            $current = (string)($_POST['current_password'] ?? '');
            $new = (string)($_POST['new_password'] ?? '');
            $user = current_user();
            if (!password_verify($current, $user['password_hash'])) throw new RuntimeException('كلمة المرور الحالية غير صحيحة.');
            if (strlen($new) < 6) throw new RuntimeException('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل.');
            execute_sql('UPDATE users SET password_hash=? WHERE id=?', [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            flash('success', 'تم تغيير كلمة المرور.');
            if ($user['role'] === 'admin') redirect('admin_dashboard');
            if ($user['role'] === 'provider') redirect('provider_profile');
            redirect('customer_profile');
        }

        case 'provider_profile_save': {
            require_role('provider');
            $user = current_user();
            $business = trim($_POST['business_name'] ?? '');
            $bio = trim($_POST['bio'] ?? '');
            $city = trim($_POST['city'] ?? 'Baghdad');
            $area = trim($_POST['area'] ?? '');
            $instagram = trim($_POST['instagram_url'] ?? '');
            $equipment = trim($_POST['equipment'] ?? '');
            $image = null;
            if (!empty($_FILES['profile_image']['name'])) {
                $image = upload_media($_FILES['profile_image'], 'providers');
            }
            $existing = fetch_one('SELECT * FROM provider_profiles WHERE user_id = ?', [$user['id']]);
            if ($existing) {
                $sql = 'UPDATE provider_profiles SET business_name=?, bio=?, city=?, area=?, instagram_url=?, equipment=?' . ($image ? ', profile_image=?' : '') . ' WHERE user_id=?';
                $params = [$business, $bio, $city, $area, $instagram, $equipment];
                if ($image) $params[] = $image;
                $params[] = $user['id'];
                execute_sql($sql, $params);
                $providerId = (int)$existing['id'];
            } else {
                execute_sql('INSERT INTO provider_profiles (user_id, business_name, bio, city, area, instagram_url, equipment, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [$user['id'], $business, $bio, $city, $area, $instagram, $equipment, $image]);
                $providerId = (int)last_insert_id();
            }
            execute_sql('DELETE FROM provider_categories WHERE provider_id = ?', [$providerId]);
            foreach (($_POST['categories'] ?? []) as $catId) {
                execute_sql('INSERT IGNORE INTO provider_categories (provider_id, category_id) VALUES (?, ?)', [$providerId, (int)$catId]);
            }
            log_audit('provider_profile_save', 'provider', $providerId);
            flash('success', 'Provider profile saved.');
            redirect('provider_profile');
        }

        case 'provider_package_save': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id = ?', [current_user()['id']]);
            if (!$profile) throw new RuntimeException('Create provider profile first.');
            $id = (int)($_POST['id'] ?? 0);
            $category = (int)($_POST['category_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $price = (float)($_POST['price'] ?? 0);
            $duration = (int)($_POST['duration_minutes'] ?? 60);
            $delivery = (int)($_POST['delivery_days'] ?? 3);
            $drone = isset($_POST['includes_drone']) ? 1 : 0;
            $video = isset($_POST['includes_video']) ? 1 : 0;
            $premium = isset($_POST['is_premium']) ? 1 : 0;
            $status = $_POST['status'] ?? 'active';
            if ($title === '' || $category <= 0 || $price <= 0) throw new RuntimeException('Package title, category, and price are required.');
            if ($id > 0) {
                execute_sql('UPDATE packages SET category_id=?, title=?, description=?, price=?, duration_minutes=?, delivery_days=?, includes_drone=?, includes_video=?, is_premium=?, status=? WHERE id=? AND provider_id=?', [$category, $title, $description, $price, $duration, $delivery, $drone, $video, $premium, $status, $id, $profile['id']]);
                log_audit('provider_package_update', 'package', $id);
            } else {
                execute_sql('INSERT INTO packages (provider_id, category_id, title, description, price, duration_minutes, delivery_days, includes_drone, includes_video, is_premium, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [$profile['id'], $category, $title, $description, $price, $duration, $delivery, $drone, $video, $premium, $status]);
                log_audit('provider_package_create', 'package', (int)last_insert_id());
            }
            flash('success', 'Package saved.');
            redirect('provider_packages');
        }

        case 'provider_package_delete': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id = ?', [current_user()['id']]);
            execute_sql('UPDATE packages SET status="inactive" WHERE id=? AND provider_id=?', [(int)$_POST['id'], $profile['id']]);
            flash('success', 'Package disabled.');
            redirect('provider_packages');
        }

        case 'portfolio_upload': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id = ?', [current_user()['id']]);
            $path = upload_media($_FILES['media'] ?? [], 'portfolio');
            if (!$path) throw new RuntimeException('Please choose a media file.');
            $mediaType = is_video($path) ? 'video' : 'image';
            execute_sql('INSERT INTO portfolios (provider_id, category_id, media_type, file_url, caption) VALUES (?, ?, ?, ?, ?)', [$profile['id'], ($_POST['category_id'] ?: null), $mediaType, $path, trim($_POST['caption'] ?? '')]);
            flash('success', 'Portfolio item uploaded.');
            redirect('provider_portfolio');
        }

        case 'portfolio_delete': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id = ?', [current_user()['id']]);
            execute_sql('DELETE FROM portfolios WHERE id=? AND provider_id=?', [(int)$_POST['id'], $profile['id']]);
            flash('success', 'Portfolio item deleted.');
            redirect('provider_portfolio');
        }

        case 'availability_save': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id = ?', [current_user()['id']]);
            execute_sql('DELETE FROM availability WHERE provider_id = ?', [$profile['id']]);
            foreach (range(0, 6) as $day) {
                if (!empty($_POST['available'][$day])) {
                    $start = $_POST['start_time'][$day] ?: '09:00';
                    $end = $_POST['end_time'][$day] ?: '18:00';
                    execute_sql('INSERT INTO availability (provider_id, day_of_week, start_time, end_time, is_available) VALUES (?, ?, ?, ?, 1)', [$profile['id'], $day, $start, $end]);
                }
            }
            flash('success', 'Availability saved.');
            redirect('provider_availability');
        }

        case 'create_booking': {
            require_role('customer');
            $packageId = (int)($_POST['package_id'] ?? 0);
            $package = fetch_one('SELECT p.*, pp.user_id AS provider_user_id FROM packages p JOIN provider_profiles pp ON pp.id=p.provider_id JOIN users u ON u.id=pp.user_id WHERE p.id=? AND p.status="active" AND u.status="active"', [$packageId]);
            if (!$package) throw new RuntimeException('Package not available.');
            $urgent = isset($_POST['urgent']) ? 1 : 0;
            $urgentFee = $urgent ? (float)setting('urgent_fee', '10000') : 0;
            $basePrice = (float)$package['price'];
            $total = $basePrice + $urgentFee;
            $money = calculate_money($basePrice);
            $appRevenue = $money['app_commission'] + $urgentFee;
            $date = $_POST['booking_date'] ?? '';
            $time = $_POST['start_time'] ?? '';
            $location = trim($_POST['location'] ?? '');
            if (!$date || !$time || $location === '') throw new RuntimeException('التاريخ والوقت والموقع مطلوبة.');
            if ($date < date('Y-m-d')) throw new RuntimeException('لا يمكن الحجز بتاريخ سابق.');
            $endTime = date('H:i:s', strtotime($time . ' +' . (int)$package['duration_minutes'] . ' minutes'));
            $dayOfWeek = (int)date('w', strtotime($date));
            $availability = fetch_one('SELECT * FROM availability WHERE provider_id=? AND day_of_week=? AND is_available=1', [$package['provider_id'], $dayOfWeek]);
            $hasAnyAvailability = fetch_one('SELECT id FROM availability WHERE provider_id=? LIMIT 1', [$package['provider_id']]);
            if ($hasAnyAvailability && (!$availability || $time < $availability['start_time'] || $endTime > $availability['end_time'])) {
                throw new RuntimeException('مقدم الخدمة غير متاح في هذا اليوم أو الوقت.');
            }
            $conflict = fetch_one('SELECT id FROM bookings WHERE provider_id=? AND booking_date=? AND status NOT IN ("rejected","cancelled","refunded") AND start_time < ? AND end_time > ? LIMIT 1', [$package['provider_id'], $date, $endTime, $time]);
            if ($conflict) throw new RuntimeException('هذا الوقت محجوز عند مقدم الخدمة. اختر وقتاً آخر.');
            $customerConflict = fetch_one('SELECT id FROM bookings WHERE customer_id=? AND booking_date=? AND status NOT IN ("rejected","cancelled","refunded") AND start_time < ? AND end_time > ? LIMIT 1', [current_user()['id'], $date, $endTime, $time]);
            if ($customerConflict) throw new RuntimeException('لديك حجز آخر يتعارض مع هذا الموعد.');
            execute_sql('INSERT INTO bookings (booking_code, customer_id, provider_id, package_id, category_id, booking_date, start_time, end_time, location, customer_notes, urgent, urgent_fee_amount, total_price, app_commission, provider_amount, status, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "pending", "unpaid")', [booking_code(), current_user()['id'], $package['provider_id'], $package['id'], $package['category_id'], $date, $time, $endTime, $location, trim($_POST['customer_notes'] ?? ''), $urgent, $urgentFee, $total, $appRevenue, $money['provider_amount']]);
            $bookingId = (int)last_insert_id();
            log_audit('create_booking', 'booking', $bookingId);
            flash('success', 'Booking request sent to provider.');
            redirect('messages', ['booking_id' => $bookingId]);
        }

        case 'booking_status': {
            require_auth();
            $bookingId = (int)($_POST['booking_id'] ?? 0);
            $newStatus = $_POST['status'] ?? '';
            $booking = fetch_one('SELECT * FROM bookings WHERE id=?', [$bookingId]);
            if (!$booking) throw new RuntimeException('Booking not found.');
            $user = current_user();
            $provider = fetch_one('SELECT * FROM provider_profiles WHERE id=?', [$booking['provider_id']]);
            $allowed = false;
            if ($user['role'] === 'admin') $allowed = true;
            if ($user['role'] === 'provider' && (int)$provider['user_id'] === (int)$user['id'] && in_array($newStatus, ['accepted','rejected','in_progress','completed','cancelled'], true)) $allowed = true;
            if ($user['role'] === 'customer' && (int)$booking['customer_id'] === (int)$user['id'] && in_array($newStatus, ['cancelled','completed'], true)) $allowed = true;
            if (!$allowed) throw new RuntimeException('You cannot change this booking status.');
            $paymentStatus = $_POST['payment_status'] ?? null;
            if ($paymentStatus && $user['role'] === 'admin') {
                execute_sql('UPDATE bookings SET status=?, payment_status=? WHERE id=?', [$newStatus, $paymentStatus, $bookingId]);
            } else {
                execute_sql('UPDATE bookings SET status=? WHERE id=?', [$newStatus, $bookingId]);
            }
            if ($newStatus === 'completed' && $booking['status'] !== 'completed') {
                execute_sql('UPDATE provider_profiles SET total_bookings = total_bookings + 1 WHERE id = ?', [$booking['provider_id']]);
            }
            log_audit('booking_status_' . $newStatus, 'booking', $bookingId);
            flash('success', 'Booking updated.');
            if (!empty($_POST['return_url'])) { redirect_raw($_POST['return_url']); }
            redirect($_POST['return_page'] ?? 'customer_dashboard');
        }

        case 'send_message': {
            require_auth();
            $bookingId = (int)($_POST['booking_id'] ?? 0);
            $message = trim($_POST['message'] ?? '');
            if ($message === '') throw new RuntimeException('Message cannot be empty.');
            $booking = fetch_one('SELECT b.*, pp.user_id AS provider_user_id FROM bookings b JOIN provider_profiles pp ON pp.id=b.provider_id WHERE b.id=?', [$bookingId]);
            if (!$booking) throw new RuntimeException('Booking not found.');
            $user = current_user();
            $allowed = $user['role'] === 'admin' || (int)$booking['customer_id'] === (int)$user['id'] || (int)$booking['provider_user_id'] === (int)$user['id'];
            if (!$allowed) throw new RuntimeException('Forbidden.');
            execute_sql('INSERT INTO booking_messages (booking_id, sender_id, message) VALUES (?, ?, ?)', [$bookingId, $user['id'], $message]);
            redirect('messages', ['booking_id' => $bookingId]);
        }

        case 'review_create': {
            require_role('customer');
            $bookingId = (int)($_POST['booking_id'] ?? 0);
            $booking = fetch_one('SELECT * FROM bookings WHERE id=? AND customer_id=? AND status="completed"', [$bookingId, current_user()['id']]);
            if (!$booking) throw new RuntimeException('You can review only completed bookings.');
            $rating = max(1, min(5, (int)($_POST['rating'] ?? 5)));
            execute_sql('INSERT INTO reviews (booking_id, customer_id, provider_id, rating, comment) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE rating=VALUES(rating), comment=VALUES(comment)', [$bookingId, current_user()['id'], $booking['provider_id'], $rating, trim($_POST['comment'] ?? '')]);
            $avg = fetch_one('SELECT AVG(rating) AS avg_rating FROM reviews WHERE provider_id=?', [$booking['provider_id']]);
            execute_sql('UPDATE provider_profiles SET rating=? WHERE id=?', [round((float)$avg['avg_rating'], 2), $booking['provider_id']]);
            flash('success', 'Review submitted.');
            redirect('customer_dashboard');
        }

        case 'dispute_open': {
            require_auth();
            $bookingId = (int)($_POST['booking_id'] ?? 0);
            $booking = fetch_one('SELECT b.*, pp.user_id AS provider_user_id FROM bookings b JOIN provider_profiles pp ON pp.id=b.provider_id WHERE b.id=?', [$bookingId]);
            if (!$booking) throw new RuntimeException('Booking not found.');
            $user = current_user();
            $allowed = (int)$booking['customer_id'] === (int)$user['id'] || (int)$booking['provider_user_id'] === (int)$user['id'];
            if (!$allowed && $user['role'] !== 'admin') throw new RuntimeException('Forbidden.');
            execute_sql('INSERT INTO disputes (booking_id, opened_by, reason, description, status) VALUES (?, ?, ?, ?, "open")', [$bookingId, $user['id'], trim($_POST['reason'] ?? 'Issue'), trim($_POST['description'] ?? '')]);
            execute_sql('UPDATE bookings SET status="disputed" WHERE id=?', [$bookingId]);
            flash('success', 'Dispute opened. Admin will review it.');
            redirect('messages', ['booking_id' => $bookingId]);
        }

        case 'provider_subscription_request': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id=?', [current_user()['id']]);
            $plan = $_POST['plan_name'] ?? 'Basic';
            $price = $plan === 'Pro' ? (float)setting('subscription_pro_price','50000') : (float)setting('subscription_basic_price','25000');
            execute_sql('INSERT INTO provider_subscriptions (provider_id, plan_name, price, status, notes) VALUES (?, ?, ?, "pending", ?)', [$profile['id'], $plan, $price, trim($_POST['notes'] ?? '')]);
            execute_sql('UPDATE provider_profiles SET subscription_status="pending" WHERE id=?', [$profile['id']]);
            flash('success', 'Subscription request sent to admin.');
            redirect('provider_money');
        }

        case 'provider_featured_request': {
            require_role('provider');
            $profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id=?', [current_user()['id']]);
            $price = (float)setting('featured_provider_price','50000');
            execute_sql('INSERT INTO featured_providers (provider_id, category_id, city, amount_paid, status) VALUES (?, ?, ?, ?, "pending")', [$profile['id'], ($_POST['category_id'] ?: null), trim($_POST['city'] ?? $profile['city']), $price]);
            flash('success', 'Featured request sent to admin.');
            redirect('provider_money');
        }

        case 'admin_user_status': {
            require_role('admin');
            $userId = (int)($_POST['user_id'] ?? 0);
            $status = $_POST['status'] ?? 'active';
            if (!in_array($status, ['active','pending','blocked','rejected'], true)) {
                throw new RuntimeException('حالة الحساب غير صحيحة.');
            }
            execute_sql('UPDATE users SET status=? WHERE id=? AND role != "admin"', [$status, $userId]);
            flash('success', 'تم تحديث حالة المستخدم.');
            redirect('admin_users');
        }

        case 'admin_provider_status': {
            require_role('admin');
            $userId = (int)$_POST['user_id'];
            $status = $_POST['status'] ?? 'pending';
            $verified = isset($_POST['verified']) ? 1 : 0;
            execute_sql('UPDATE users SET status=? WHERE id=? AND role="provider"', [$status, $userId]);
            execute_sql('UPDATE provider_profiles SET verified=? WHERE user_id=?', [$verified, $userId]);
            flash('success', 'Provider updated.');
            redirect('admin_providers');
        }

        case 'admin_category_save': {
            require_role('admin');
            $id = (int)($_POST['id'] ?? 0);
            $fields = [trim($_POST['name_ar'] ?? ''), trim($_POST['name_en'] ?? ''), trim($_POST['icon'] ?? ''), $_POST['status'] ?? 'active', (int)($_POST['sort_order'] ?? 0)];
            if ($id > 0) {
                execute_sql('UPDATE categories SET name_ar=?, name_en=?, icon=?, status=?, sort_order=? WHERE id=?', [...$fields, $id]);
            } else {
                execute_sql('INSERT INTO categories (name_ar, name_en, icon, status, sort_order) VALUES (?, ?, ?, ?, ?)', $fields);
            }
            flash('success', 'Category saved.');
            redirect('admin_categories');
        }

        case 'admin_payment_add': {
            require_role('admin');
            $bookingId = (int)$_POST['booking_id'];
            $booking = fetch_one('SELECT * FROM bookings WHERE id=?', [$bookingId]);
            if (!$booking) throw new RuntimeException('Booking not found.');
            $amount = max(0, (float)($_POST['amount_paid'] ?? 0));
            if ($amount <= 0) throw new RuntimeException('أدخل مبلغاً صحيحاً.');
            $paymentRecordStatus = $_POST['status'] ?? 'confirmed';
            execute_sql('INSERT INTO payments (booking_id, customer_id, provider_id, amount_paid, payment_method, transaction_reference, app_commission, provider_amount, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [$bookingId, $booking['customer_id'], $booking['provider_id'], $amount, $_POST['payment_method'] ?? 'cash', trim($_POST['transaction_reference'] ?? ''), $booking['app_commission'], $booking['provider_amount'], $paymentRecordStatus]);
            $paid = fetch_one('SELECT COALESCE(SUM(amount_paid),0) AS total FROM payments WHERE booking_id=? AND status="confirmed"', [$bookingId]);
            $confirmedTotal = (float)($paid['total'] ?? 0);
            $payStatus = $confirmedTotal >= (float)$booking['total_price'] ? 'paid' : ($confirmedTotal > 0 ? 'deposit_paid' : 'unpaid');
            execute_sql('UPDATE bookings SET payment_status=?, status=IF(status IN ("accepted","awaiting_payment") AND ? IN ("deposit_paid","paid"), "confirmed", status) WHERE id=?', [$payStatus, $payStatus, $bookingId]);
            flash('success', 'Payment recorded.');
            redirect('admin_bookings');
        }

        case 'admin_subscription_status': {
            require_role('admin');
            $id = (int)$_POST['id'];
            $status = $_POST['status'] ?? 'active';
            $starts = $_POST['starts_at'] ?: date('Y-m-d');
            $ends = $_POST['ends_at'] ?: date('Y-m-d', strtotime('+30 days'));
            execute_sql('UPDATE provider_subscriptions SET status=?, starts_at=?, ends_at=? WHERE id=?', [$status, $starts, $ends, $id]);
            $row = fetch_one('SELECT * FROM provider_subscriptions WHERE id=?', [$id]);
            if ($row) execute_sql('UPDATE provider_profiles SET subscription_status=? WHERE id=?', [$status, $row['provider_id']]);
            flash('success', 'Subscription updated.');
            redirect('admin_money');
        }

        case 'admin_featured_status': {
            require_role('admin');
            $id = (int)$_POST['id'];
            $status = $_POST['status'] ?? 'active';
            $starts = $_POST['starts_at'] ?: date('Y-m-d');
            $ends = $_POST['ends_at'] ?: date('Y-m-d', strtotime('+30 days'));
            execute_sql('UPDATE featured_providers SET status=?, starts_at=?, ends_at=? WHERE id=?', [$status, $starts, $ends, $id]);
            $row = fetch_one('SELECT * FROM featured_providers WHERE id=?', [$id]);
            if ($row && $status === 'active') {
                execute_sql('UPDATE provider_profiles SET featured_until=? WHERE id=?', [$ends, $row['provider_id']]);
            } elseif ($row) {
                execute_sql('UPDATE provider_profiles SET featured_until=NULL WHERE id=?', [$row['provider_id']]);
            }
            flash('success', 'Featured placement updated.');
            redirect('admin_money');
        }

        case 'admin_ad_save': {
            require_role('admin');
            $id = (int)($_POST['id'] ?? 0);
            $image = null;
            if (!empty($_FILES['image']['name'])) $image = upload_media($_FILES['image'], 'ads');
            if ($id > 0) {
                $sql = 'UPDATE ads SET advertiser_name=?, title=?, target_url=?, category_id=?, city=?, starts_at=?, ends_at=?, price=?, placement=?, status=?' . ($image ? ', image_url=?' : '') . ' WHERE id=?';
                $params = [trim($_POST['advertiser_name']), trim($_POST['title']), trim($_POST['target_url'] ?? ''), ($_POST['category_id'] ?: null), trim($_POST['city'] ?? ''), ($_POST['starts_at'] ?: null), ($_POST['ends_at'] ?: null), (float)$_POST['price'], $_POST['placement'], $_POST['status']];
                if ($image) $params[] = $image;
                $params[] = $id;
                execute_sql($sql, $params);
            } else {
                execute_sql('INSERT INTO ads (advertiser_name, title, image_url, target_url, category_id, city, starts_at, ends_at, price, placement, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [trim($_POST['advertiser_name']), trim($_POST['title']), $image, trim($_POST['target_url'] ?? ''), ($_POST['category_id'] ?: null), trim($_POST['city'] ?? ''), ($_POST['starts_at'] ?: null), ($_POST['ends_at'] ?: null), (float)$_POST['price'], $_POST['placement'], $_POST['status']]);
            }
            flash('success', 'Ad saved.');
            redirect('admin_ads');
        }

        case 'admin_dispute_update': {
            require_role('admin');
            $id = (int)$_POST['id'];
            execute_sql('UPDATE disputes SET status=?, admin_decision=? WHERE id=?', [$_POST['status'] ?? 'under_review', trim($_POST['admin_decision'] ?? ''), $id]);
            flash('success', 'Dispute updated.');
            redirect('admin_disputes');
        }

        case 'admin_settings_save': {
            require_role('admin');
            foreach (['commission_percent','urgent_fee','subscription_basic_price','subscription_pro_price','featured_provider_price'] as $key) {
                execute_sql('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)', [$key, trim($_POST[$key] ?? '')]);
            }
            flash('success', 'Settings saved.');
            redirect('admin_money');
        }

        default:
            throw new RuntimeException('Unknown action: ' . $action);
    }
} catch (Throwable $e) {
    try {
        if (db()->inTransaction()) db()->rollBack();
    } catch (Throwable $ignored) {
        // Database may be unavailable; preserve the original error.
    }
    flash('danger', $e->getMessage());
    $returnUrl = trim((string)($_POST['return_url'] ?? ''));
    if ($returnUrl !== '' && strpos($returnUrl, '://') === false && strpos($returnUrl, '//') !== 0) {
        redirect_raw($returnUrl);
    }
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '') {
        $parts = parse_url($referer);
        $sameHost = empty($parts['host']) || $parts['host'] === ($_SERVER['HTTP_HOST'] ?? '');
        if ($sameHost) {
            $path = ($parts['path'] ?? 'index.php') . (!empty($parts['query']) ? '?' . $parts['query'] : '');
            redirect_raw($path);
        }
    }
    redirect_raw('index.php');
}
