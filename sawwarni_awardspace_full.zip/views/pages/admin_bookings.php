<?php
$pageTitle='إدارة الحجوزات';
$status=trim($_GET['status']??''); $params=[];
$sql='SELECT b.*, p.title AS package_title, pp.business_name, cu.name AS customer_name FROM bookings b JOIN packages p ON p.id=b.package_id JOIN provider_profiles pp ON pp.id=b.provider_id JOIN users cu ON cu.id=b.customer_id WHERE 1=1';
if($status!==''){ $sql.=' AND b.status=?'; $params[]=$status; }
$sql.=' ORDER BY b.id DESC LIMIT 200';
$bookings=fetch_all($sql,$params);
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container card"><div class="section-title"><h1>إدارة الحجوزات</h1><form method="get" class="pill-row"><input type="hidden" name="page" value="admin_bookings"><select name="status"><option value="">كل الحالات</option><?php foreach(['pending','accepted','confirmed','completed','cancelled','rejected','disputed','refunded'] as $s): ?><option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select><button class="btn">فلترة</button></form></div>
  <div class="table-wrap"><table><thead><tr><th>الكود</th><th>العميل</th><th>المصور</th><th>الباقة</th><th>التاريخ</th><th>السعر</th><th>الحالة</th><th>الدفع</th><th>تسجيل دفع</th></tr></thead><tbody>
    <?php foreach($bookings as $b): ?><tr>
      <td><a href="<?= url('messages',['booking_id'=>$b['id']]) ?>"><?= e($b['booking_code']) ?></a></td><td><?= e($b['customer_name']) ?></td><td><?= e($b['business_name']) ?></td><td><?= e($b['package_title']) ?></td><td><?= e($b['booking_date'].' '.substr($b['start_time'],0,5)) ?></td><td><?= format_iqd($b['total_price']) ?><br><span class="mini">عمولة <?= format_iqd($b['app_commission']) ?></span></td><td><?= status_badge($b['status']) ?></td><td><?= status_badge($b['payment_status']) ?></td>
      <td>
        <form method="post" action="actions.php" class="grid-form" style="min-width:260px"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $b['id'] ?>"><input type="hidden" name="return_page" value="admin_bookings"><select name="status"><?php foreach(['pending','accepted','awaiting_payment','confirmed','in_progress','completed','cancelled','refunded','disputed'] as $s): ?><option value="<?= $s ?>" <?= $b['status']===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select><select name="payment_status"><?php foreach(['unpaid','deposit_paid','paid','provider_paid','refunded'] as $ps): ?><option value="<?= $ps ?>" <?= $b['payment_status']===$ps?'selected':'' ?>><?= $ps ?></option><?php endforeach; ?></select><button class="btn small">تحديث</button></form>
        <form method="post" action="actions.php" class="grid-form" style="margin-top:8px;min-width:260px"><?= csrf_field() ?><input type="hidden" name="action" value="admin_payment_add"><input type="hidden" name="booking_id" value="<?= $b['id'] ?>"><input type="number" name="amount_paid" placeholder="المبلغ" value="<?= e($b['total_price']) ?>"><select name="payment_method"><option>cash</option><option>manual_deposit</option><option>zaincash</option><option>fastpay</option><option>qi</option><option>card</option></select><input name="transaction_reference" placeholder="reference"><select name="status"><option>confirmed</option><option>pending</option><option>refunded</option></select><button class="btn small green">تسجيل دفع</button></form>
      </td>
    </tr><?php endforeach; ?>
    <?php if(!$bookings): ?><tr><td colspan="9" class="empty">لا توجد حجوزات.</td></tr><?php endif; ?>
  </tbody></table></div>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
