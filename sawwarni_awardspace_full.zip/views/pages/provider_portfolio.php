<?php
$pageTitle='البورتفوليو'; $user=current_user(); $profile=fetch_one('SELECT * FROM provider_profiles WHERE user_id=?',[$user['id']]); $providerId=$profile['id']??0;
$categories=fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order');
$items=fetch_all('SELECT pf.*, c.name_ar FROM portfolios pf LEFT JOIN categories c ON c.id=pf.category_id WHERE pf.provider_id=? ORDER BY pf.id DESC',[$providerId]);
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <h1>إضافة أعمال</h1>
    <form class="grid-form" method="post" action="actions.php" enctype="multipart/form-data">
      <?= csrf_field() ?><input type="hidden" name="action" value="portfolio_upload">
      <label>التصنيف<select name="category_id"><option value="">بدون</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select></label>
      <label>صورة/فيديو<input type="file" name="media" accept="image/*,video/*" required></label>
      <label>Caption<input name="caption"></label>
      <button class="btn primary">رفع</button>
    </form>
  </div>
  <div class="card"><h2>ملاحظة</h2><p class="muted">ارفع أفضل الأعمال فقط. البورتفوليو هو أهم عامل لزيادة الحجوزات.</p><p>الحد الأقصى للملف الواحد 25MB.</p></div>
</div></section>
<section class="section"><div class="container portfolio-grid">
  <?php foreach($items as $item): ?><div class="portfolio-item"><?php if($item['media_type']==='video'): ?><video controls src="<?= e($item['file_url']) ?>"></video><?php else: ?><img src="<?= e($item['file_url']) ?>"><?php endif; ?><div style="padding:10px"><strong><?= e($item['name_ar'] ?? '') ?></strong><p><?= e($item['caption']) ?></p><form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="portfolio_delete"><input type="hidden" name="id" value="<?= $item['id'] ?>"><button class="btn small danger" data-confirm="Delete item?">حذف</button></form></div></div><?php endforeach; ?>
  <?php if(!$items): ?><div class="card empty">لا توجد أعمال بعد.</div><?php endif; ?>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
