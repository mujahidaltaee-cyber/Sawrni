<?php
$pageTitle='لوحة الإدارة';
$stats = [
  'users' => fetch_one('SELECT COUNT(*) c FROM users WHERE role != "admin"')['c'] ?? 0,
  'customers' => fetch_one('SELECT COUNT(*) c FROM users WHERE role="customer"')['c'] ?? 0,
  'providers' => fetch_one('SELECT COUNT(*) c FROM users WHERE role="provider"')['c'] ?? 0,
  'providers_pending' => fetch_one('SELECT COUNT(*) c FROM users WHERE role="provider" AND status="pending"')['c'] ?? 0,
  'bookings' => fetch_one('SELECT COUNT(*) c FROM bookings')['c'] ?? 0,
  'completed' => fetch_one('SELECT COUNT(*) c FROM bookings WHERE status="completed"')['c'] ?? 0,
  'commission' => fetch_one('SELECT COALESCE(SUM(app_commission),0) s FROM bookings WHERE status="completed"')['s'] ?? 0,
  'provider_amount' => fetch_one('SELECT COALESCE(SUM(provider_amount),0) s FROM bookings WHERE status="completed"')['s'] ?? 0,
  'subs' => fetch_one('SELECT COALESCE(SUM(price),0) s FROM provider_subscriptions WHERE status="active"')['s'] ?? 0,
  'featured' => fetch_one('SELECT COALESCE(SUM(amount_paid),0) s FROM featured_providers WHERE status="active"')['s'] ?? 0,
  'ads' => fetch_one('SELECT COALESCE(SUM(price),0) s FROM ads WHERE status="active"')['s'] ?? 0,
];
$platformRevenue = (float)$stats['commission'] + (float)$stats['subs'] + (float)$stats['featured'] + (float)$stats['ads'];
$partnerShare = $platformRevenue / 3;
$recent = fetch_all('SELECT b.*, p.title AS package_title, pp.business_name, u.name AS customer_name FROM bookings b JOIN packages p ON p.id=b.package_id JOIN provider_profiles pp ON pp.id=b.provider_id JOIN users u ON u.id=b.customer_id ORDER BY b.id DESC LIMIT 12');
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title"><div><span class="eyebrow">Management Portal</span><h1>لوحة إدارة صورني</h1><p class="muted">إدارة المستخدمين والحجوزات ومصادر دخل المنصة.</p></div><span class="role-chip admin-chip">دخول إداري خاص</span></div>
  <div class="tabs"><a href="<?= url('admin_users') ?>">المستخدمون</a><a href="<?= url('admin_providers') ?>">مقدمو الخدمة</a><a href="<?= url('admin_categories') ?>">التصنيفات</a><a href="<?= url('admin_bookings') ?>">الحجوزات</a><a href="<?= url('admin_money') ?>">المالية</a><a href="<?= url('admin_ads') ?>">الإعلانات</a><a href="<?= url('admin_disputes') ?>">الشكاوى</a><a href="<?= url('admin_audit') ?>">سجل النشاط</a></div>

  <div class="dash-grid">
    <div class="metric"><span>العملاء</span><strong><?= (int)$stats['customers'] ?></strong></div>
    <div class="metric"><span>مقدمو الخدمة</span><strong><?= (int)$stats['providers'] ?></strong></div>
    <div class="metric"><span>بانتظار الموافقة</span><strong><?= (int)$stats['providers_pending'] ?></strong></div>
    <div class="metric"><span>الحجوزات المكتملة</span><strong><?= (int)$stats['completed'] ?> / <?= (int)$stats['bookings'] ?></strong></div>
  </div>

  <div class="revenue-panel" style="margin-top:20px">
    <div><span>دخل الحجوزات والرسوم العاجلة</span><strong><?= format_iqd($stats['commission']) ?></strong></div>
    <div><span>الاشتراكات</span><strong><?= format_iqd($stats['subs']) ?></strong></div>
    <div><span>الظهور المميز</span><strong><?= format_iqd($stats['featured']) ?></strong></div>
    <div><span>الإعلانات</span><strong><?= format_iqd($stats['ads']) ?></strong></div>
    <div class="revenue-total"><span>إجمالي دخل المنصة قبل المصاريف</span><strong><?= format_iqd($platformRevenue) ?></strong></div>
    <div class="revenue-share"><span>حصة كل شريك من 3 قبل المصاريف</span><strong><?= format_iqd($partnerShare) ?></strong></div>
  </div>

  <div class="grid grid-2" style="margin-top:20px">
    <div class="card"><h2>آخر الحجوزات</h2><div class="table-wrap"><table><thead><tr><th>الكود</th><th>العميل</th><th>المصور</th><th>السعر</th><th>الحالة</th><th></th></tr></thead><tbody>
      <?php foreach($recent as $b): ?><tr><td><?= e($b['booking_code']) ?></td><td><?= e($b['customer_name']) ?></td><td><?= e($b['business_name']) ?></td><td><?= format_iqd($b['total_price']) ?></td><td><?= status_badge($b['status']) ?></td><td><a class="btn small" href="<?= url('messages',['booking_id'=>$b['id']]) ?>">فتح</a></td></tr><?php endforeach; ?>
      <?php if(!$recent): ?><tr><td colspan="6" class="empty">لا توجد حجوزات بعد.</td></tr><?php endif; ?>
    </tbody></table></div></div>
    <div class="card">
      <span class="eyebrow">أمان الإدارة</span><h2>تغيير كلمة مرور الإدارة</h2><p class="muted">الحساب يبدأ باسم المستخدم Mujahid وكلمة المرور 123456. يفضل تغييرها بعد أول اختبار.</p>
      <form class="grid-form" method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="change_password"><label>كلمة المرور الحالية<input type="password" name="current_password" required></label><label>كلمة المرور الجديدة<input type="password" name="new_password" minlength="6" required></label><button class="btn primary">تغيير كلمة المرور</button></form>
    </div>
  </div>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
