<?php
$pageTitle='الأوقات المتاحة'; $user=current_user(); $profile=fetch_one('SELECT * FROM provider_profiles WHERE user_id=?',[$user['id']]); $providerId=$profile['id']??0;
$rows=fetch_all('SELECT * FROM availability WHERE provider_id=?',[$providerId]); $map=[]; foreach($rows as $r){$map[(int)$r['day_of_week']]=$r;}
$days=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container card">
  <h1>أوقات العمل الأسبوعية</h1>
  <form method="post" action="actions.php" class="grid-form">
    <?= csrf_field() ?><input type="hidden" name="action" value="availability_save">
    <div class="table-wrap"><table><thead><tr><th>اليوم</th><th>متاح</th><th>من</th><th>إلى</th></tr></thead><tbody>
      <?php foreach($days as $i=>$day): $r=$map[$i]??null; ?><tr>
        <td><?= e($day) ?></td>
        <td><input type="checkbox" name="available[<?= $i ?>]" <?= $r?'checked':'' ?>></td>
        <td><input type="time" name="start_time[<?= $i ?>]" value="<?= e($r ? substr($r['start_time'],0,5) : '09:00') ?>"></td>
        <td><input type="time" name="end_time[<?= $i ?>]" value="<?= e($r ? substr($r['end_time'],0,5) : '18:00') ?>"></td>
      </tr><?php endforeach; ?>
    </tbody></table></div>
    <button class="btn primary">حفظ الأوقات</button>
  </form>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
