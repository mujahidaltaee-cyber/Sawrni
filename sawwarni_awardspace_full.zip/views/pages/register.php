<?php
$type = ($_GET['type'] ?? 'customer') === 'provider' ? 'provider' : 'customer';
$pageTitle = $type === 'provider' ? 'إنشاء حساب مقدم خدمة' : 'إنشاء حساب عميل';
require APP_ROOT . '/views/layout/header.php';
?>
<section class="auth-section"><div class="container auth-narrow">
  <div class="auth-card <?= $type === 'provider' ? 'provider-auth' : 'customer-auth' ?>">
    <span class="eyebrow"><?= $type === 'provider' ? 'انضم إلى شبكة صورني' : 'ابدأ الحجز بسهولة' ?></span>
    <h1><?= $type === 'provider' ? 'حساب مقدم خدمة' : 'حساب عميل جديد' ?></h1>
    <p class="muted"><?= $type === 'provider' ? 'للمصور، الفيديو، الدرون، الاستوديو والمونتاج. الحساب يخضع لموافقة الإدارة.' : 'قارن الأسعار والأعمال واحجز وراقب حالة طلبك.' ?></p>
    <div class="account-switch">
      <a class="<?= $type === 'customer' ? 'active' : '' ?>" href="<?= url('register',['type'=>'customer']) ?>">عميل</a>
      <a class="<?= $type === 'provider' ? 'active' : '' ?>" href="<?= url('register',['type'=>'provider']) ?>">مقدم خدمة</a>
    </div>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $type === 'provider' ? 'register_provider' : 'register_customer' ?>">
      <label>الاسم الكامل<input name="name" required maxlength="150"></label>
      <?php if ($type === 'provider'): ?>
        <label>اسم العمل أو الصفحة<input name="business_name" required maxlength="190" placeholder="مثال: Ali Photography"></label>
      <?php endif; ?>
      <div class="form-row">
        <label>البريد الإلكتروني<input type="email" name="email" required autocomplete="email"></label>
        <label>رقم الهاتف<input name="phone" required placeholder="07XXXXXXXXX"></label>
      </div>
      <?php if ($type === 'provider'): ?>
        <div class="form-row">
          <label>المدينة<input name="city" value="بغداد" required></label>
          <label>رابط Instagram<input name="instagram_url" placeholder="https://instagram.com/..."></label>
        </div>
      <?php endif; ?>
      <label>كلمة المرور<input type="password" name="password" minlength="6" required autocomplete="new-password"></label>
      <button class="btn <?= $type === 'provider' ? 'provider-btn' : 'customer-btn' ?>" type="submit">إنشاء الحساب</button>
    </form>
    <div class="auth-footer">لديك حساب؟ <a href="<?= $type === 'provider' ? url('provider_login') : url('customer_login') ?>">تسجيل الدخول</a></div>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
