<?php
$pageTitle = 'حسابي';
$user = current_user();
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <span class="eyebrow">بيانات العميل</span><h1>الملف الشخصي</h1>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?><input type="hidden" name="action" value="customer_profile_save">
      <label>الاسم<input name="name" value="<?= e($user['name']) ?>" required></label>
      <label>البريد الإلكتروني<input value="<?= e($user['email']) ?>" disabled></label>
      <label>رقم الهاتف<input name="phone" value="<?= e($user['phone']) ?>"></label>
      <button class="btn customer-btn">حفظ التعديلات</button>
    </form>
  </div>
  <div class="card">
    <span class="eyebrow">الأمان</span><h2>تغيير كلمة المرور</h2>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?><input type="hidden" name="action" value="change_password">
      <label>كلمة المرور الحالية<input type="password" name="current_password" required></label>
      <label>كلمة المرور الجديدة<input type="password" name="new_password" minlength="6" required></label>
      <button class="btn">تغيير كلمة المرور</button>
    </form>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
