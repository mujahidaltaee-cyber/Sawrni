<?php
$pageTitle='الاشتراكات والظهور'; $user=current_user(); $profile=fetch_one('SELECT * FROM provider_profiles WHERE user_id=?',[$user['id']]); $providerId=$profile['id']??0;
$subs=fetch_all('SELECT * FROM provider_subscriptions WHERE provider_id=? ORDER BY id DESC',[$providerId]);
$featured=fetch_all('SELECT fp.*, c.name_ar FROM featured_providers fp LEFT JOIN categories c ON c.id=fp.category_id WHERE fp.provider_id=? ORDER BY fp.id DESC',[$providerId]);
$categories=fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order');
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card"><h1>طلب اشتراك شهري</h1><p class="muted">Basic: <?= format_iqd(setting('subscription_basic_price','25000')) ?> — Pro: <?= format_iqd(setting('subscription_pro_price','50000')) ?></p>
    <form method="post" action="actions.php" class="grid-form"><?= csrf_field() ?><input type="hidden" name="action" value="provider_subscription_request"><label>الخطة<select name="plan_name"><option>Basic</option><option>Pro</option></select></label><label>ملاحظات<textarea name="notes"></textarea></label><button class="btn primary">إرسال طلب الاشتراك</button></form>
  </div>
  <div class="card"><h1>طلب ظهور مميز</h1><p class="muted">السعر الافتراضي: <?= format_iqd(setting('featured_provider_price','50000')) ?> شهرياً</p>
    <form method="post" action="actions.php" class="grid-form"><?= csrf_field() ?><input type="hidden" name="action" value="provider_featured_request"><label>التصنيف<select name="category_id"><option value="">عام</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['name_ar']) ?></option><?php endforeach; ?></select></label><label>المدينة<input name="city" value="<?= e($profile['city'] ?? 'Baghdad') ?>"></label><button class="btn gold">إرسال طلب الظهور</button></form>
  </div>
</div></section>
<section class="section"><div class="container grid grid-2">
  <div class="card"><h2>اشتراكاتي</h2><div class="table-wrap"><table><tr><th>الخطة</th><th>السعر</th><th>الحالة</th><th>من/إلى</th></tr><?php foreach($subs as $s): ?><tr><td><?= e($s['plan_name']) ?></td><td><?= format_iqd($s['price']) ?></td><td><?= status_badge($s['status']) ?></td><td><?= e($s['starts_at'].' - '.$s['ends_at']) ?></td></tr><?php endforeach; ?></table></div></div>
  <div class="card"><h2>ظهوري المميز</h2><div class="table-wrap"><table><tr><th>التصنيف</th><th>السعر</th><th>الحالة</th><th>من/إلى</th></tr><?php foreach($featured as $f): ?><tr><td><?= e($f['name_ar'] ?? 'عام') ?></td><td><?= format_iqd($f['amount_paid']) ?></td><td><?= status_badge($f['status']) ?></td><td><?= e($f['starts_at'].' - '.$f['ends_at']) ?></td></tr><?php endforeach; ?></table></div></div>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
