<?php
$pageTitle = 'لوحة المصور';
$user = current_user();
$profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id=?', [$user['id']]);
$providerId = $profile['id'] ?? 0;
$stats = [
  'bookings' => fetch_one('SELECT COUNT(*) c FROM bookings WHERE provider_id=?', [$providerId])['c'] ?? 0,
  'completed' => fetch_one('SELECT COUNT(*) c FROM bookings WHERE provider_id=? AND status="completed"', [$providerId])['c'] ?? 0,
  'earnings' => fetch_one('SELECT COALESCE(SUM(provider_amount),0) s FROM bookings WHERE provider_id=? AND status="completed"', [$providerId])['s'] ?? 0,
  'commission' => fetch_one('SELECT COALESCE(SUM(app_commission),0) s FROM bookings WHERE provider_id=? AND status="completed"', [$providerId])['s'] ?? 0,
];
$bookings = fetch_all('SELECT b.*, p.title AS package_title, u.name AS customer_name FROM bookings b JOIN packages p ON p.id=b.package_id JOIN users u ON u.id=b.customer_id WHERE b.provider_id=? ORDER BY b.id DESC LIMIT 30', [$providerId]);
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title"><h1>لوحة المصور</h1><span><?= $profile ? status_badge($user['status']) : '' ?></span></div>
  <div class="tabs">
    <a href="<?= url('provider_profile') ?>">الملف</a><a href="<?= url('provider_packages') ?>">الباقات</a><a href="<?= url('provider_portfolio') ?>">البورتفوليو</a><a href="<?= url('provider_availability') ?>">الأوقات</a><a href="<?= url('provider_money') ?>">الاشتراكات والظهور</a>
  </div>
  <?php if($user['status']!=='active'): ?><div class="alert warning">حسابك بانتظار موافقة المدير، تستطيع تجهيز ملفك الآن.</div><?php endif; ?>
  <div class="dash-grid">
    <div class="metric"><span>كل الحجوزات</span><strong><?= (int)$stats['bookings'] ?></strong></div>
    <div class="metric"><span>مكتملة</span><strong><?= (int)$stats['completed'] ?></strong></div>
    <div class="metric"><span>أرباحك</span><strong><?= format_iqd($stats['earnings']) ?></strong></div>
    <div class="metric"><span>عمولة التطبيق</span><strong><?= format_iqd($stats['commission']) ?></strong></div>
  </div>
  <div class="card" style="margin-top:20px"><h2>آخر الحجوزات</h2>
    <div class="table-wrap"><table><thead><tr><th>الكود</th><th>العميل</th><th>الباقة</th><th>التاريخ</th><th>السعر</th><th>الحالة</th><th></th></tr></thead><tbody>
      <?php foreach($bookings as $b): ?><tr><td><?= e($b['booking_code']) ?></td><td><?= e($b['customer_name']) ?></td><td><?= e($b['package_title']) ?></td><td><?= e($b['booking_date'].' '.substr($b['start_time'],0,5)) ?></td><td><?= format_iqd($b['total_price']) ?></td><td><?= status_badge($b['status']) ?></td><td><a class="btn small" href="<?= url('messages',['booking_id'=>$b['id']]) ?>">فتح</a></td></tr><?php endforeach; ?>
      <?php if(!$bookings): ?><tr><td colspan="7" class="empty">لا توجد حجوزات.</td></tr><?php endif; ?>
    </tbody></table></div>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
