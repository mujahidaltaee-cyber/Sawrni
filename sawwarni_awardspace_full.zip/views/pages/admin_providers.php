<?php
$pageTitle='إدارة المصورين';
$providers=fetch_all('SELECT pp.*, u.id AS user_id, u.name, u.email, u.phone, u.status FROM provider_profiles pp JOIN users u ON u.id=pp.user_id ORDER BY FIELD(u.status,"pending","active","rejected","blocked"), pp.id DESC');
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container card"><h1>إدارة المصورين</h1>
  <div class="table-wrap"><table><thead><tr><th>المصور</th><th>تواصل</th><th>مدينة</th><th>حالة</th><th>Verified</th><th>تحكم</th></tr></thead><tbody>
  <?php foreach($providers as $p): ?><tr>
    <td><strong><?= e($p['business_name']) ?></strong><br><?= e($p['name']) ?></td><td><?= e($p['email']) ?><br><?= e($p['phone']) ?></td><td><?= e($p['city']) ?></td><td><?= status_badge($p['status']) ?></td><td><?= $p['verified']?'✅':'—' ?></td>
    <td><form method="post" action="actions.php" class="grid-form" style="min-width:240px"><?= csrf_field() ?><input type="hidden" name="action" value="admin_provider_status"><input type="hidden" name="user_id" value="<?= $p['user_id'] ?>"><select name="status"><option value="pending" <?= $p['status']==='pending'?'selected':'' ?>>pending</option><option value="active" <?= $p['status']==='active'?'selected':'' ?>>active</option><option value="rejected" <?= $p['status']==='rejected'?'selected':'' ?>>rejected</option><option value="blocked" <?= $p['status']==='blocked'?'selected':'' ?>>blocked</option></select><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="verified" <?= $p['verified']?'checked':'' ?> style="width:auto"> Verified</label><button class="btn small primary">حفظ</button></form></td>
  </tr><?php endforeach; ?>
  <?php if(!$providers): ?><tr><td colspan="6" class="empty">لا يوجد مزودين.</td></tr><?php endif; ?>
  </tbody></table></div>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
