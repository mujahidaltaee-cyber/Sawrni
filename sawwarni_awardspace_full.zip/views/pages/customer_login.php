<?php $pageTitle = 'دخول العميل'; require APP_ROOT . '/views/layout/header.php'; ?>
<section class="auth-section"><div class="container auth-narrow">
  <div class="auth-card customer-auth">
    <span class="eyebrow">واجهة العميل</span><h1>تسجيل الدخول</h1><p class="muted">ادخل لمتابعة حجوزاتك وحجز مصور جديد.</p>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?><input type="hidden" name="action" value="customer_login">
      <label>البريد الإلكتروني<input type="email" name="email" required autocomplete="email"></label>
      <label>كلمة المرور<input type="password" name="password" required autocomplete="current-password"></label>
      <button class="btn customer-btn" type="submit">دخول العميل</button>
    </form>
    <div class="auth-footer">ليس لديك حساب؟ <a href="<?= url('register',['type'=>'customer']) ?>">إنشاء حساب عميل</a></div>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
