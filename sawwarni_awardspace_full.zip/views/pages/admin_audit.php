<?php
$pageTitle='Audit Log'; $logs=fetch_all('SELECT al.*, u.name FROM audit_logs al LEFT JOIN users u ON u.id=al.user_id ORDER BY al.id DESC LIMIT 300');
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container card"><h1>Audit Log</h1><div class="table-wrap"><table><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>IP</th><th>Details</th></tr><?php foreach($logs as $l): ?><tr><td><?= e($l['created_at']) ?></td><td><?= e($l['name'] ?? 'System') ?></td><td><?= e($l['action']) ?></td><td><?= e($l['entity_type'].' #'.$l['entity_id']) ?></td><td><?= e($l['ip_address']) ?></td><td><?= e($l['details']) ?></td></tr><?php endforeach; ?></table></div></div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
