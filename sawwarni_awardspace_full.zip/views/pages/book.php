<?php
$packageId = (int)($_GET['package_id'] ?? 0);
$package = fetch_one(
    'SELECT p.*, c.name_ar, c.icon, pp.business_name, pp.city, u.status AS provider_status
     FROM packages p
     JOIN categories c ON c.id=p.category_id
     JOIN provider_profiles pp ON pp.id=p.provider_id
     JOIN users u ON u.id=pp.user_id
     WHERE p.id=? AND p.status="active" AND u.status="active"',
    [$packageId]
);
if (!$package) {
    http_response_code(404);
    $pageTitle='الباقة غير متاحة';
    require APP_ROOT.'/views/layout/header.php';
    echo '<section class="section"><div class="container"><div class="card empty">الباقة غير موجودة أو مقدم الخدمة غير مفعل.</div></div></section>';
    require APP_ROOT.'/views/layout/footer.php';
    return;
}
$urgentFee = (float)setting('urgent_fee','10000');
$commissionPercent = (float)setting('commission_percent','10');
$bookingAds = fetch_all('SELECT * FROM ads WHERE status="active" AND (placement="booking" OR placement="all") AND (starts_at IS NULL OR starts_at <= CURDATE()) AND (ends_at IS NULL OR ends_at >= CURDATE()) ORDER BY id DESC LIMIT 2');
$money = calculate_money((float)$package['price']);
$pageTitle = 'إنشاء حجز';
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <span class="eyebrow">ملخص الخدمة</span>
    <h1><?= e($package['title']) ?></h1>
    <p class="muted"><?= e($package['business_name']) ?> • <?= e($package['city']) ?> • <?= e($package['icon'].' '.$package['name_ar']) ?></p>
    <p><?= nl2br(e($package['description'])) ?></p>
    <div class="divider"></div>
    <div class="booking-summary-list">
      <p><span>سعر الباقة</span><strong><?= format_iqd($package['price']) ?></strong></p>
      <p><span>إجمالي العميل</span><strong data-booking-total><?= format_iqd($package['price']) ?></strong></p>
      <p><span>دخل صورني (عمولة <?= e((string)$commissionPercent) ?>%)</span><strong data-booking-commission><?= format_iqd($money['app_commission']) ?></strong></p>
      <p><span>مستحق مقدم الخدمة</span><strong data-booking-provider><?= format_iqd($money['provider_amount']) ?></strong></p>
    </div>
    <div class="alert warning">الحجز العاجل يضيف <?= format_iqd($urgentFee) ?> إلى الإجمالي وتذهب الرسوم بالكامل إلى منصة صورني.</div>
  </div>
  <div class="card">
    <span class="eyebrow">تفاصيل الموعد</span><h2>إرسال طلب الحجز</h2>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create_booking">
      <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
      <div class="form-row">
        <label>تاريخ الجلسة<input type="date" name="booking_date" min="<?= date('Y-m-d') ?>" required></label>
        <label>وقت البداية<input type="time" name="start_time" required></label>
      </div>
      <label>الموقع<input name="location" placeholder="مثال: بغداد - المنصور" required></label>
      <label>تفاصيل الجلسة<textarea name="customer_notes" placeholder="عدد الأشخاص، نوع الصور، المناسبة، وأي تفاصيل مهمة..."></textarea></label>
      <label class="check-line">
        <input type="checkbox" name="urgent" value="1" data-urgent-checkbox data-base="<?= e((string)$package['price']) ?>" data-fee="<?= e((string)$urgentFee) ?>" data-commission="<?= e((string)$commissionPercent) ?>">
        حجز عاجل أو في نفس اليوم + <?= format_iqd($urgentFee) ?>
      </label>
      <button class="btn customer-btn" type="submit">إرسال الطلب إلى مقدم الخدمة</button>
    </form>
  </div>
</div></section>
<?php if($bookingAds): ?><section class="section"><div class="container grid grid-2"><?php foreach($bookingAds as $ad): ?><a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank"><?php if($ad['image_url']): ?><img src="<?= e($ad['image_url']) ?>" alt="" style="height:120px;width:100%;object-fit:cover;border-radius:14px;margin-bottom:10px"><?php endif; ?><strong>إعلان مرتبط بالحجز: <?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span></a><?php endforeach; ?></div></section><?php endif; ?>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
