<?php
$pageTitle = 'لوحة العميل';
$user = current_user();
$bookings = fetch_all(
    'SELECT b.*, p.title AS package_title, pp.business_name
     FROM bookings b
     JOIN packages p ON p.id=b.package_id
     JOIN provider_profiles pp ON pp.id=b.provider_id
     WHERE b.customer_id=? ORDER BY b.id DESC',
    [$user['id']]
);
$stats = [
    'all' => count($bookings),
    'active' => count(array_filter($bookings, fn($b) => in_array($b['status'], ['pending','accepted','awaiting_payment','confirmed','in_progress'], true))),
    'completed' => count(array_filter($bookings, fn($b) => $b['status']==='completed')),
    'spent' => array_sum(array_map(fn($b) => in_array($b['payment_status'], ['paid','provider_paid'], true) ? (float)$b['total_price'] : 0, $bookings)),
];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title"><div><span class="eyebrow">Customer Portal</span><h1>لوحة العميل</h1><p class="muted">تابع الطلبات، المدفوعات والمحادثات من مكان واحد.</p></div><a class="btn customer-btn" href="<?= url('providers') ?>">حجز خدمة جديدة</a></div>
  <div class="dash-grid">
    <div class="metric"><span>كل الحجوزات</span><strong><?= (int)$stats['all'] ?></strong></div>
    <div class="metric"><span>الحجوزات الفعالة</span><strong><?= (int)$stats['active'] ?></strong></div>
    <div class="metric"><span>الحجوزات المكتملة</span><strong><?= (int)$stats['completed'] ?></strong></div>
    <div class="metric"><span>إجمالي المدفوع</span><strong><?= format_iqd($stats['spent']) ?></strong></div>
  </div>

  <div class="card" style="margin-top:20px">
    <div class="section-title"><h2>حجوزاتي</h2><a class="btn small" href="<?= url('customer_profile') ?>">بيانات الحساب</a></div>
    <div class="table-wrap"><table>
      <thead><tr><th>رقم الحجز</th><th>مقدم الخدمة</th><th>الباقة</th><th>الموعد</th><th>الإجمالي</th><th>الحالة</th><th>الدفع</th><th>الإجراءات</th></tr></thead>
      <tbody>
      <?php foreach($bookings as $b): ?>
        <tr>
          <td><strong><?= e($b['booking_code']) ?></strong><?php if($b['urgent']): ?><br><span class="badge badge-yellow">عاجل</span><?php endif; ?></td>
          <td><?= e($b['business_name']) ?></td>
          <td><?= e($b['package_title']) ?></td>
          <td><?= e($b['booking_date'].' '.substr($b['start_time'],0,5)) ?></td>
          <td><?= format_iqd($b['total_price']) ?></td>
          <td><?= status_badge($b['status']) ?></td>
          <td><?= status_badge($b['payment_status']) ?></td>
          <td><a class="btn small" href="<?= url('messages',['booking_id'=>$b['id']]) ?>">تفاصيل ومحادثة</a></td>
        </tr>
        <?php if($b['status']==='completed'): ?>
          <tr><td colspan="8">
            <form method="post" action="actions.php" class="form-row">
              <?= csrf_field() ?><input type="hidden" name="action" value="review_create"><input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>">
              <label>التقييم<select name="rating"><option value="5">5 نجوم</option><option value="4">4 نجوم</option><option value="3">3 نجوم</option><option value="2">نجمتان</option><option value="1">نجمة واحدة</option></select></label>
              <label>التعليق<input name="comment" placeholder="شارك رأيك بالخدمة"></label>
              <button class="btn green" type="submit">إرسال التقييم</button>
            </form>
          </td></tr>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php if(!$bookings): ?><tr><td colspan="8" class="empty">لا توجد حجوزات بعد. اختر مقدم خدمة وأرسل أول طلب.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
