<?php
$pageTitle = 'احجز مصورك بسهولة';
$categories = fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order, id');
$ads = fetch_all('SELECT * FROM ads WHERE status="active" AND (placement="home" OR placement="all") AND (starts_at IS NULL OR starts_at <= CURDATE()) AND (ends_at IS NULL OR ends_at >= CURDATE()) ORDER BY id DESC LIMIT 3');
$featured = fetch_all('SELECT pp.*, u.name, u.status, MIN(p.price) AS starting_price FROM provider_profiles pp JOIN users u ON u.id=pp.user_id LEFT JOIN packages p ON p.provider_id=pp.id AND p.status="active" WHERE u.status="active" AND (pp.featured_until IS NOT NULL AND pp.featured_until >= CURDATE() OR pp.verified=1) GROUP BY pp.id ORDER BY pp.featured_until DESC, pp.rating DESC LIMIT 6');
require APP_ROOT . '/views/layout/header.php';
?>
<section class="hero">
  <div class="container hero-grid">
    <div>
      <h1>احجز مصور، فيديو، درون أو جلسة تصوير خلال دقائق.</h1>
      <p>صورني منصة تجمع العملاء مع مصورين موثوقين وباقات واضحة. الحجز يتم من الموقع، والعمولة الافتراضية <?= e(setting('commission_percent','10')) ?>% من كل حجز مكتمل.</p>
      <div class="pill-row">
        <a class="btn primary" href="<?= url('providers') ?>">شوف المصورين</a>
        <a class="btn" href="<?= url('register', ['type'=>'provider']) ?>">انضم كمصور</a>
      </div>
    </div>
    <div class="hero-card">
      <div>
        <h2>صورني</h2>
        <p>Graduation • Wedding • Drone • Reels • Studio • Editing</p>
      </div>
      <div class="grid grid-2">
        <div class="stat"><strong>10%</strong><span>عمولة التطبيق</span></div>
        <div class="stat"><strong>90%</strong><span>للمصور</span></div>
        <div class="stat"><strong>+Urgent</strong><span>حجوزات نفس اليوم</span></div>
        <div class="stat"><strong>Featured</strong><span>ظهور مدفوع</span></div>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="search-card">
    <form class="search-form" method="get" action="index.php">
      <input type="hidden" name="page" value="providers">
      <input name="q" placeholder="اسم المصور أو الخدمة">
      <select name="category_id">
        <option value="">كل التصنيفات</option>
        <?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?>
      </select>
      <input name="city" placeholder="المدينة" value="Baghdad">
      <button class="btn primary" type="submit">بحث</button>
    </form>
  </div>
</section>

<?php if ($ads): ?>
<section class="section"><div class="container grid grid-3">
  <?php foreach ($ads as $ad): ?>
    <a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank">
      <?php if ($ad['image_url']): ?><img src="<?= e($ad['image_url']) ?>" alt="" style="border-radius:16px;height:150px;width:100%;object-fit:cover;margin-bottom:10px"><?php endif; ?>
      <strong>إعلان: <?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span>
    </a>
  <?php endforeach; ?>
</div></section>
<?php endif; ?>

<section class="section">
  <div class="container">
    <div class="section-title"><h2>التصنيفات</h2><span class="muted">اختر نوع الجلسة</span></div>
    <div class="grid grid-4">
      <?php foreach ($categories as $c): ?>
        <a class="category-card" href="<?= url('providers', ['category_id'=>$c['id']]) ?>">
          <div class="category-icon"><?= e($c['icon']) ?></div>
          <h3><?= e($c['name_ar']) ?></h3>
          <p class="muted"><?= e($c['name_en']) ?></p>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title"><h2>مصورين مميزين</h2><a class="btn" href="<?= url('providers') ?>">عرض الكل</a></div>
    <div class="grid grid-3">
      <?php foreach ($featured as $p): ?>
        <a class="provider-card" href="<?= url('provider', ['id'=>$p['id']]) ?>">
          <?php if ($p['profile_image']): ?><img class="provider-cover" src="<?= e($p['profile_image']) ?>" alt=""><?php else: ?><div class="provider-cover"></div><?php endif; ?>
          <div class="provider-body">
            <div class="provider-head"><div><h3><?= e($p['business_name']) ?> <?= $p['verified'] ? '✅' : '' ?></h3><p class="muted"><?= e($p['city']) ?> • ⭐ <?= e((string)$p['rating']) ?></p></div></div>
            <p class="price">يبدأ من <?= $p['starting_price'] ? format_iqd($p['starting_price']) : '—' ?></p>
          </div>
        </a>
      <?php endforeach; ?>
      <?php if (!$featured): ?><div class="card empty">لا توجد ملفات مميزة بعد.</div><?php endif; ?>
    </div>
  </div>
</section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
