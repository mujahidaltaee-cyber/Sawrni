<?php
$pageTitle = 'المصورين';
$q = trim($_GET['q'] ?? '');
$city = trim($_GET['city'] ?? '');
$cat = (int)($_GET['category_id'] ?? 0);
$categories = fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order, id');
$params = [];
$sql = 'SELECT pp.*, u.name, MIN(p.price) AS starting_price, COUNT(DISTINCT p.id) AS package_count
        FROM provider_profiles pp
        JOIN users u ON u.id=pp.user_id
        LEFT JOIN packages p ON p.provider_id=pp.id AND p.status="active"
        LEFT JOIN provider_categories pc ON pc.provider_id=pp.id
        WHERE u.status="active"';
if ($q !== '') { $sql .= ' AND (pp.business_name LIKE ? OR pp.bio LIKE ? OR pp.equipment LIKE ?)'; $params[]="%$q%"; $params[]="%$q%"; $params[]="%$q%"; }
if ($city !== '') { $sql .= ' AND pp.city LIKE ?'; $params[]="%$city%"; }
if ($cat > 0) { $sql .= ' AND (pc.category_id=? OR p.category_id=?)'; $params[]=$cat; $params[]=$cat; }
$sql .= ' GROUP BY pp.id ORDER BY CASE WHEN pp.featured_until >= CURDATE() THEN 0 ELSE 1 END, pp.verified DESC, pp.rating DESC, pp.total_bookings DESC';
$providers = fetch_all($sql, $params);
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title"><h1>المصورين ومزودي الخدمة</h1><span class="muted"><?= count($providers) ?> نتيجة</span></div>
  <div class="search-card">
    <form class="search-form" method="get">
      <input type="hidden" name="page" value="providers">
      <input name="q" value="<?= e($q) ?>" placeholder="بحث بالاسم أو الخدمة">
      <select name="category_id"><option value="">كل التصنيفات</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $cat===(int)$c['id']?'selected':'' ?>><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select>
      <input name="city" value="<?= e($city) ?>" placeholder="المدينة">
      <button class="btn primary">بحث</button>
    </form>
  </div>

  <?php if($ads): ?><div class="grid grid-2" style="margin-top:18px"><?php foreach($ads as $ad): ?><a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank"><?php if($ad['image_url']): ?><img src="<?= e($ad['image_url']) ?>" alt="" style="height:120px;width:100%;object-fit:cover;border-radius:14px;margin-bottom:10px"><?php endif; ?><strong>إعلان: <?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span></a><?php endforeach; ?></div><?php endif; ?>
  <div class="grid grid-3" style="margin-top:20px">
    <?php foreach($providers as $p): ?>
      <a class="provider-card" href="<?= url('provider',['id'=>$p['id']]) ?>">
        <?php if($p['profile_image']): ?><img class="provider-cover" src="<?= e($p['profile_image']) ?>" alt=""><?php else: ?><div class="provider-cover"></div><?php endif; ?>
        <div class="provider-body">
          <h3><?= e($p['business_name']) ?> <?= $p['verified']?'✅':'' ?> <?= ($p['featured_until'] && $p['featured_until'] >= date('Y-m-d'))?'⭐':'' ?></h3>
          <p class="muted"><?= e($p['city']) ?> <?= $p['area']?'• '.e($p['area']):'' ?> • Rating <?= e((string)$p['rating']) ?></p>
          <p><?= e(short_text($p['bio'] ?? '', 120)) ?></p>
          <p class="price">يبدأ من <?= $p['starting_price'] ? format_iqd($p['starting_price']) : '—' ?></p>
          <span class="badge badge-gray"><?= (int)$p['package_count'] ?> باقة</span>
        </div>
      </a>
    <?php endforeach; ?>
    <?php if(!$providers): ?><div class="card empty">لا توجد نتائج. جرّب بحث مختلف.</div><?php endif; ?>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
