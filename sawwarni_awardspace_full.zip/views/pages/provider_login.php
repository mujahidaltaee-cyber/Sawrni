<?php $pageTitle = 'دخول مقدم الخدمة'; require APP_ROOT . '/views/layout/header.php'; ?>
<section class="auth-section"><div class="container auth-narrow">
  <div class="auth-card provider-auth">
    <span class="eyebrow">واجهة مقدم الخدمة</span><h1>تسجيل دخول المصور</h1><p class="muted">أدر ملفك، الباقات، معرض الأعمال، المواعيد والأرباح.</p>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?><input type="hidden" name="action" value="provider_login">
      <label>البريد الإلكتروني<input type="email" name="email" required autocomplete="email"></label>
      <label>كلمة المرور<input type="password" name="password" required autocomplete="current-password"></label>
      <button class="btn provider-btn" type="submit">دخول مقدم الخدمة</button>
    </form>
    <div class="auth-footer">لم تنضم بعد؟ <a href="<?= url('register',['type'=>'provider']) ?>">إنشاء حساب مقدم خدمة</a></div>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
