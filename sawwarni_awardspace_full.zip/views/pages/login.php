<?php $pageTitle = 'اختيار نوع الدخول'; require APP_ROOT . '/views/layout/header.php'; ?>
<section class="auth-section">
  <div class="container">
    <div class="auth-heading"><span class="eyebrow">مرحباً بك</span><h1>اختر الواجهة المناسبة</h1><p>حساب الإدارة غير ظاهر هنا ولا يمكن إنشاؤه من الموقع.</p></div>
    <div class="grid grid-2 auth-choice-grid">
      <a class="account-choice customer-choice" href="<?= url('customer_login') ?>">
        <div class="choice-icon">👤</div><div><h2>دخول العميل</h2><p>البحث، المقارنة، الحجز، متابعة الطلب، المحادثة والتقييم.</p><span>متابعة كعميل ←</span></div>
      </a>
      <a class="account-choice provider-choice" href="<?= url('provider_login') ?>">
        <div class="choice-icon">📷</div><div><h2>دخول مقدم الخدمة</h2><p>للمصور، مصور الفيديو، الدرون، الاستوديو والمونتير.</p><span>متابعة كمقدم خدمة ←</span></div>
      </a>
    </div>
  </div>
</section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
