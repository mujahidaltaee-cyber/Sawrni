<?php
require_auth();
$bookingId = (int)($_GET['booking_id'] ?? 0);
$booking = fetch_one(
    'SELECT b.*, p.title AS package_title, pp.business_name, pp.user_id AS provider_user_id, cu.name AS customer_name
     FROM bookings b
     JOIN packages p ON p.id=b.package_id
     JOIN provider_profiles pp ON pp.id=b.provider_id
     JOIN users cu ON cu.id=b.customer_id
     WHERE b.id=?',
    [$bookingId]
);
if (!$booking) {
    http_response_code(404);
    $pageTitle='الحجز غير موجود';
    require APP_ROOT.'/views/layout/header.php';
    echo '<section class="section"><div class="container"><div class="card empty">الحجز غير موجود.</div></div></section>';
    require APP_ROOT.'/views/layout/footer.php';
    return;
}
$user=current_user();
$allowed = $user['role']==='admin' || (int)$booking['customer_id']===(int)$user['id'] || (int)$booking['provider_user_id']===(int)$user['id'];
if (!$allowed) { http_response_code(403); exit('Forbidden'); }
$messages = fetch_all('SELECT bm.*, u.name, u.role FROM booking_messages bm JOIN users u ON u.id=bm.sender_id WHERE bm.booking_id=? ORDER BY bm.id ASC', [$bookingId]);
$existingDispute = fetch_one('SELECT * FROM disputes WHERE booking_id=? ORDER BY id DESC LIMIT 1', [$bookingId]);
$returnUrl = 'index.php?page=messages&booking_id=' . $bookingId;
$pageTitle = 'تفاصيل الحجز';
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <span class="eyebrow">Booking Details</span><h1><?= e($booking['booking_code']) ?></h1>
    <p><strong><?= e($booking['package_title']) ?></strong> مع <?= e($booking['business_name']) ?></p>
    <div class="booking-summary-list">
      <p><span>العميل</span><strong><?= e($booking['customer_name']) ?></strong></p>
      <p><span>الموعد</span><strong><?= e($booking['booking_date']) ?> — <?= e(substr($booking['start_time'],0,5)) ?></strong></p>
      <p><span>الموقع</span><strong><?= e($booking['location']) ?></strong></p>
      <p><span>حالة الحجز</span><strong><?= status_badge($booking['status']) ?></strong></p>
      <p><span>حالة الدفع</span><strong><?= status_badge($booking['payment_status']) ?></strong></p>
      <p><span>الإجمالي على العميل</span><strong><?= format_iqd($booking['total_price']) ?></strong></p>
      <p><span>دخل صورني</span><strong><?= format_iqd($booking['app_commission']) ?></strong></p>
      <p><span>مستحق مقدم الخدمة</span><strong><?= format_iqd($booking['provider_amount']) ?></strong></p>
      <?php if((float)$booking['urgent_fee_amount'] > 0): ?><p><span>ضمن دخل صورني: رسوم عاجلة</span><strong><?= format_iqd($booking['urgent_fee_amount']) ?></strong></p><?php endif; ?>
    </div>
    <?php if($booking['customer_notes']): ?><div class="alert"><strong>ملاحظات العميل:</strong><br><?= nl2br(e($booking['customer_notes'])) ?></div><?php endif; ?>

    <div class="pill-row">
      <?php if($user['role']==='provider' && (int)$booking['provider_user_id']===(int)$user['id']): ?>
        <?php if($booking['status']==='pending'): ?>
          <form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $bookingId ?>"><input type="hidden" name="return_url" value="<?= e($returnUrl) ?>"><button class="btn green" name="status" value="accepted">قبول الطلب</button></form>
          <form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $bookingId ?>"><input type="hidden" name="return_url" value="<?= e($returnUrl) ?>"><button class="btn danger" name="status" value="rejected">رفض الطلب</button></form>
        <?php endif; ?>
        <?php if(in_array($booking['status'],['accepted','confirmed'],true)): ?>
          <form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $bookingId ?>"><input type="hidden" name="return_url" value="<?= e($returnUrl) ?>"><button class="btn" name="status" value="in_progress">بدء تنفيذ الجلسة</button></form>
        <?php endif; ?>
        <?php if($booking['status']==='in_progress'): ?>
          <form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $bookingId ?>"><input type="hidden" name="return_url" value="<?= e($returnUrl) ?>"><button class="btn green" name="status" value="completed">تسجيل الخدمة كمكتملة</button></form>
        <?php endif; ?>
      <?php endif; ?>

      <?php if($user['role']==='customer' && (int)$booking['customer_id']===(int)$user['id']): ?>
        <?php if(in_array($booking['status'],['pending','accepted','awaiting_payment','confirmed'],true)): ?>
          <form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $bookingId ?>"><input type="hidden" name="return_url" value="<?= e($returnUrl) ?>"><button class="btn danger" name="status" value="cancelled" data-confirm="هل تريد إلغاء هذا الحجز؟">إلغاء الحجز</button></form>
        <?php endif; ?>
        <?php if($booking['status']==='in_progress'): ?>
          <form method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?= $bookingId ?>"><input type="hidden" name="return_url" value="<?= e($returnUrl) ?>"><button class="btn green" name="status" value="completed">تأكيد اكتمال الخدمة</button></form>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    <div class="divider"></div>
    <?php if($existingDispute): ?>
      <div class="alert warning"><strong>الشكوى الحالية:</strong> <?= e($existingDispute['reason']) ?><br>الحالة: <?= status_badge($existingDispute['status']) ?><?php if($existingDispute['admin_decision']): ?><br>قرار الإدارة: <?= nl2br(e($existingDispute['admin_decision'])) ?><?php endif; ?></div>
    <?php elseif($user['role']!=='admin'): ?>
      <form method="post" action="actions.php" class="grid-form">
        <?= csrf_field() ?><input type="hidden" name="action" value="dispute_open"><input type="hidden" name="booking_id" value="<?= $bookingId ?>">
        <h3>فتح شكوى</h3>
        <input name="reason" placeholder="سبب الشكوى" required>
        <textarea name="description" placeholder="اكتب تفاصيل المشكلة"></textarea>
        <button class="btn danger" type="submit">إرسال الشكوى للإدارة</button>
      </form>
    <?php endif; ?>
  </div>

  <div class="card">
    <span class="eyebrow">Booking Chat</span><h2>المحادثة</h2>
    <div class="message-list">
      <?php foreach($messages as $m): ?><div class="message <?= (int)$m['sender_id']===(int)$user['id']?'mine':'other' ?>"><strong><?= e($m['name']) ?> <span class="mini">/ <?= e($m['role']) ?></span></strong><p><?= nl2br(e($m['message'])) ?></p><span class="mini"><?= e($m['created_at']) ?></span></div><?php endforeach; ?>
      <?php if(!$messages): ?><p class="muted">لا توجد رسائل بعد. استخدم المحادثة لتأكيد تفاصيل الجلسة.</p><?php endif; ?>
    </div>
    <form method="post" action="actions.php" class="grid-form" style="margin-top:16px">
      <?= csrf_field() ?><input type="hidden" name="action" value="send_message"><input type="hidden" name="booking_id" value="<?= $bookingId ?>">
      <textarea name="message" placeholder="اكتب رسالة مرتبطة بالحجز..." required maxlength="3000"></textarea>
      <button class="btn primary">إرسال الرسالة</button>
    </form>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
