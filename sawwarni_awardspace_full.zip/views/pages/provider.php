<?php
$id = (int)($_GET['id'] ?? 0);
$provider = fetch_one('SELECT pp.*, u.name, u.phone, u.email FROM provider_profiles pp JOIN users u ON u.id=pp.user_id WHERE pp.id=? AND u.status="active"', [$id]);
if (!$provider) { http_response_code(404); $pageTitle='Not found'; require APP_ROOT.'/views/layout/header.php'; echo '<section class="container"><div class="card">Provider not found.</div></section>'; require APP_ROOT.'/views/layout/footer.php'; return; }
$packages = fetch_all('SELECT p.*, c.name_ar, c.icon FROM packages p JOIN categories c ON c.id=p.category_id WHERE p.provider_id=? AND p.status="active" ORDER BY p.is_premium DESC, p.price', [$id]);
$portfolio = fetch_all('SELECT * FROM portfolios WHERE provider_id=? ORDER BY id DESC LIMIT 12', [$id]);
$reviews = fetch_all('SELECT r.*, u.name FROM reviews r JOIN users u ON u.id=r.customer_id WHERE r.provider_id=? ORDER BY r.id DESC LIMIT 8', [$id]);
$availability = fetch_all('SELECT * FROM availability WHERE provider_id=? ORDER BY day_of_week', [$id]);
$days=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
$pageTitle = $provider['business_name'];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <div class="provider-head">
      <?php if($provider['profile_image']): ?><img class="avatar" src="<?= e($provider['profile_image']) ?>"><?php endif; ?>
      <div><h1><?= e($provider['business_name']) ?> <?= $provider['verified']?'✅':'' ?></h1><p class="muted"><?= e($provider['city']) ?> <?= $provider['area']?'• '.e($provider['area']):'' ?> • ⭐ <?= e((string)$provider['rating']) ?></p></div>
    </div>
    <p><?= nl2br(e($provider['bio'])) ?></p>
    <p><strong>المعدات:</strong> <?= nl2br(e($provider['equipment'])) ?></p>
    <?php if($provider['instagram_url']): ?><a class="btn" target="_blank" href="<?= e($provider['instagram_url']) ?>">Instagram</a><?php endif; ?>
  </div>
  <div class="card">
    <h2>الأوقات المتاحة</h2>
    <?php foreach($availability as $a): ?><p><?= e($days[(int)$a['day_of_week']]) ?>: <?= e(substr($a['start_time'],0,5)) ?> - <?= e(substr($a['end_time'],0,5)) ?></p><?php endforeach; ?>
    <?php if(!$availability): ?><p class="muted">لم يحدد المصور أوقاتاً بعد.</p><?php endif; ?>
  </div>
</div></section>

<section class="section"><div class="container">
  <div class="section-title"><h2>الباقات</h2><span class="muted">اختار الباقة واحجز</span></div>
  <div class="grid grid-3">
    <?php foreach($packages as $p): ?>
      <div class="card">
        <span class="badge badge-gray"><?= e($p['icon'].' '.$p['name_ar']) ?></span>
        <h3><?= e($p['title']) ?> <?= $p['is_premium']?'⭐':'' ?></h3>
        <p><?= nl2br(e($p['description'])) ?></p>
        <p class="muted">المدة: <?= (int)$p['duration_minutes'] ?> دقيقة • التسليم: <?= (int)$p['delivery_days'] ?> يوم</p>
        <p class="price"><?= format_iqd($p['price']) ?></p>
        <?php if(is_logged_in() && has_role('customer')): ?><a class="btn primary" href="<?= url('book',['package_id'=>$p['id']]) ?>">احجز الآن</a><?php elseif(!is_logged_in()): ?><a class="btn primary" href="<?= url('customer_login') ?>">سجل للحجز</a><?php endif; ?>
      </div>
    <?php endforeach; ?>
    <?php if(!$packages): ?><div class="card empty">لا توجد باقات مفعّلة.</div><?php endif; ?>
  </div>
</div></section>

<section class="section"><div class="container">
  <div class="section-title"><h2>البورتفوليو</h2></div>
  <div class="portfolio-grid">
    <?php foreach($portfolio as $item): ?><div class="portfolio-item"><?php if($item['media_type']==='video'): ?><video controls src="<?= e($item['file_url']) ?>"></video><?php else: ?><img src="<?= e($item['file_url']) ?>"><?php endif; ?><div style="padding:10px"><?= e($item['caption']) ?></div></div><?php endforeach; ?>
    <?php if(!$portfolio): ?><div class="card empty">لا توجد أعمال مرفوعة بعد.</div><?php endif; ?>
  </div>
</div></section>

<section class="section"><div class="container">
  <div class="section-title"><h2>التقييمات</h2></div>
  <div class="grid grid-2">
    <?php foreach($reviews as $r): ?><div class="card"><strong><?= e($r['name']) ?> • <?= str_repeat('⭐',(int)$r['rating']) ?></strong><p><?= nl2br(e($r['comment'])) ?></p></div><?php endforeach; ?>
    <?php if(!$reviews): ?><div class="card empty">لا توجد تقييمات بعد.</div><?php endif; ?>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
