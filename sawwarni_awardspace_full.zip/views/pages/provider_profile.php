<?php
$pageTitle = 'ملف المصور';
$user = current_user();
$profile = fetch_one('SELECT * FROM provider_profiles WHERE user_id=?', [$user['id']]);
$categories = fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order');
$selected = $profile ? array_column(fetch_all('SELECT category_id FROM provider_categories WHERE provider_id=?', [$profile['id']]), 'category_id') : [];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <h1>ملف المصور</h1>
    <form class="grid-form" method="post" action="actions.php" enctype="multipart/form-data">
      <?= csrf_field() ?><input type="hidden" name="action" value="provider_profile_save">
      <label>اسم العمل<input name="business_name" value="<?= e($profile['business_name'] ?? '') ?>" required></label>
      <label>نبذة<textarea name="bio"><?= e($profile['bio'] ?? '') ?></textarea></label>
      <div class="form-row"><label>المدينة<input name="city" value="<?= e($profile['city'] ?? 'Baghdad') ?>" required></label><label>المنطقة<input name="area" value="<?= e($profile['area'] ?? '') ?>"></label></div>
      <label>Instagram URL<input name="instagram_url" value="<?= e($profile['instagram_url'] ?? '') ?>"></label>
      <label>المعدات<textarea name="equipment"><?= e($profile['equipment'] ?? '') ?></textarea></label>
      <label>صورة الملف<input type="file" name="profile_image" accept="image/*"></label>
      <h3>الخدمات</h3>
      <div class="grid grid-2">
        <?php foreach($categories as $c): ?><label style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="categories[]" value="<?= $c['id'] ?>" <?= in_array($c['id'],$selected)?'checked':'' ?> style="width:auto"> <?= e($c['icon'].' '.$c['name_ar']) ?></label><?php endforeach; ?>
      </div>
      <button class="btn primary">حفظ الملف</button>
    </form>
  </div>
  <div class="card">
    <h2>المعاينة</h2>
    <?php if($profile && $profile['profile_image']): ?><img src="<?= e($profile['profile_image']) ?>" style="border-radius:20px;height:220px;width:100%;object-fit:cover"><?php endif; ?>
    <p><strong><?= e($profile['business_name'] ?? 'اسم العمل') ?></strong></p>
    <p><?= $profile ? status_badge($user['status']) : '' ?> <?= ($profile && $profile['verified']) ? status_badge('approved') : status_badge('pending') ?></p>
    <p class="muted">كلما كان ملفك واضح، تزيد فرصة الحجز.</p>
  </div>
</div></section>

<section class="section"><div class="container"><div class="card">
  <span class="eyebrow">الأمان</span><h2>تغيير كلمة المرور</h2>
  <form method="post" action="actions.php" class="form-row">
    <?= csrf_field() ?><input type="hidden" name="action" value="change_password">
    <label>كلمة المرور الحالية<input type="password" name="current_password" required></label>
    <label>كلمة المرور الجديدة<input type="password" name="new_password" minlength="6" required></label>
    <button class="btn">تغيير كلمة المرور</button>
  </form>
</div></div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
