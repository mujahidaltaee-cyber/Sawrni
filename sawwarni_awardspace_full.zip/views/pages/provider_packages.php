<?php
$pageTitle = 'باقات المصور';
$user=current_user(); $profile=fetch_one('SELECT * FROM provider_profiles WHERE user_id=?',[$user['id']]);
$providerId=$profile['id']??0;
$categories=fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order');
$edit=null; if(!empty($_GET['edit'])) $edit=fetch_one('SELECT * FROM packages WHERE id=? AND provider_id=?',[(int)$_GET['edit'],$providerId]);
$packages=fetch_all('SELECT p.*, c.name_ar, c.icon FROM packages p JOIN categories c ON c.id=p.category_id WHERE p.provider_id=? ORDER BY p.status, p.id DESC',[$providerId]);
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container grid grid-2">
  <div class="card">
    <h1><?= $edit?'تعديل باقة':'إضافة باقة' ?></h1>
    <form class="grid-form" method="post" action="actions.php">
      <?= csrf_field() ?><input type="hidden" name="action" value="provider_package_save"><input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
      <label>التصنيف<select name="category_id" required><option value="">اختر</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= ($edit && (int)$edit['category_id']===(int)$c['id'])?'selected':'' ?>><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select></label>
      <label>عنوان الباقة<input name="title" value="<?= e($edit['title'] ?? '') ?>" required></label>
      <label>الوصف<textarea name="description"><?= e($edit['description'] ?? '') ?></textarea></label>
      <div class="form-row"><label>السعر IQD<input type="number" name="price" value="<?= e($edit['price'] ?? '') ?>" required></label><label>المدة بالدقائق<input type="number" name="duration_minutes" value="<?= e($edit['duration_minutes'] ?? '60') ?>"></label></div>
      <div class="form-row"><label>التسليم بالأيام<input type="number" name="delivery_days" value="<?= e($edit['delivery_days'] ?? '3') ?>"></label><label>الحالة<select name="status"><option value="active" <?= ($edit['status']??'active')==='active'?'selected':'' ?>>active</option><option value="inactive" <?= ($edit['status']??'')==='inactive'?'selected':'' ?>>inactive</option></select></label></div>
      <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="includes_drone" <?= !empty($edit['includes_drone'])?'checked':'' ?> style="width:auto"> تتضمن درون</label>
      <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="includes_video" <?= !empty($edit['includes_video'])?'checked':'' ?> style="width:auto"> تتضمن فيديو</label>
      <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="is_premium" <?= !empty($edit['is_premium'])?'checked':'' ?> style="width:auto"> باقة Premium</label>
      <button class="btn primary">حفظ الباقة</button>
    </form>
  </div>
  <div class="card">
    <h2>كل الباقات</h2>
    <div class="table-wrap"><table><thead><tr><th>الباقة</th><th>السعر</th><th>الحالة</th><th></th></tr></thead><tbody>
      <?php foreach($packages as $p): ?><tr><td><?= e($p['icon'].' '.$p['title']) ?><br><span class="muted"><?= e($p['name_ar']) ?></span></td><td><?= format_iqd($p['price']) ?></td><td><?= status_badge($p['status']) ?></td><td><a class="btn small" href="<?= url('provider_packages',['edit'=>$p['id']]) ?>">تعديل</a><form class="inline-form" method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="provider_package_delete"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn small danger" data-confirm="Disable package?">تعطيل</button></form></td></tr><?php endforeach; ?>
      <?php if(!$packages): ?><tr><td colspan="4" class="empty">لا توجد باقات.</td></tr><?php endif; ?>
    </tbody></table></div>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
