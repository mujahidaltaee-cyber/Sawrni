<?php
$pageTitle = 'إدارة المستخدمين';
$roleFilter = trim($_GET['role'] ?? '');
$params = [];
$sql = 'SELECT * FROM users WHERE role != "admin"';
if (in_array($roleFilter, ['customer','provider'], true)) { $sql .= ' AND role=?'; $params[]=$roleFilter; }
$sql .= ' ORDER BY id DESC LIMIT 300';
$users = fetch_all($sql, $params);
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container card">
  <div class="section-title">
    <div><span class="eyebrow">Management</span><h1>المستخدمون</h1></div>
    <form method="get" class="pill-row"><input type="hidden" name="page" value="admin_users"><select name="role"><option value="">الكل</option><option value="customer" <?= $roleFilter==='customer'?'selected':'' ?>>العملاء</option><option value="provider" <?= $roleFilter==='provider'?'selected':'' ?>>مقدمو الخدمة</option></select><button class="btn">فلترة</button></form>
  </div>
  <div class="table-wrap"><table><thead><tr><th>المستخدم</th><th>الدور</th><th>الهاتف</th><th>الحالة</th><th>آخر دخول</th><th>تحكم</th></tr></thead><tbody>
    <?php foreach ($users as $u): ?><tr>
      <td><strong><?= e($u['name']) ?></strong><br><span class="muted"><?= e($u['email']) ?></span></td>
      <td><?= e($u['role']==='customer'?'عميل':'مقدم خدمة') ?></td>
      <td><?= e($u['phone']) ?></td>
      <td><?= status_badge($u['status']) ?></td>
      <td><?= e($u['last_login_at'] ?: '—') ?></td>
      <td><form method="post" action="actions.php" class="pill-row"><?= csrf_field() ?><input type="hidden" name="action" value="admin_user_status"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><select name="status"><?php foreach(['active','pending','blocked','rejected'] as $st): ?><option value="<?= $st ?>" <?= $u['status']===$st?'selected':'' ?>><?= $st ?></option><?php endforeach; ?></select><button class="btn small">حفظ</button></form></td>
    </tr><?php endforeach; ?>
    <?php if(!$users): ?><tr><td colspan="6" class="empty">لا يوجد مستخدمون.</td></tr><?php endif; ?>
  </tbody></table></div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
