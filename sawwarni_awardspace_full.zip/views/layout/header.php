<?php
$user = current_user();
$pageTitle = $pageTitle ?? 'صورني';
$role = $user['role'] ?? 'guest';
$roleLabels = ['customer'=>'واجهة العميل','provider'=>'واجهة مقدم الخدمة','admin'=>'إدارة صورني','guest'=>''];
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#121212">
  <title><?= e($pageTitle) ?> | صورني</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="role-<?= e($role) ?>">
<header class="topbar">
  <a class="brand" href="<?= url('home') ?>"><span class="logo-mark">ص</span><span>صورني</span></a>
  <button class="nav-toggle" type="button" data-toggle-nav aria-label="القائمة">☰</button>
  <nav class="nav" data-nav>
    <?php if (!$user): ?>
      <a href="<?= url('home') ?>">الرئيسية</a>
      <a href="<?= url('providers') ?>">المصورون والخدمات</a>
      <a href="<?= url('login') ?>">تسجيل الدخول</a>
      <a class="nav-cta" href="<?= url('register',['type'=>'customer']) ?>">إنشاء حساب</a>
    <?php elseif ($user['role'] === 'customer'): ?>
      <a href="<?= url('home') ?>">الرئيسية</a>
      <a href="<?= url('providers') ?>">احجز خدمة</a>
      <a href="<?= url('customer_dashboard') ?>">حجوزاتي</a>
      <a href="<?= url('customer_profile') ?>">حسابي</a>
      <span class="role-chip customer-chip">عميل</span>
      <form method="post" action="actions.php" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="logout"><button class="link-button" type="submit">خروج</button></form>
    <?php elseif ($user['role'] === 'provider'): ?>
      <a href="<?= url('provider_dashboard') ?>">لوحة العمل</a>
      <a href="<?= url('provider_profile') ?>">الملف</a>
      <a href="<?= url('provider_packages') ?>">الباقات</a>
      <a href="<?= url('provider_portfolio') ?>">الأعمال</a>
      <a href="<?= url('provider_availability') ?>">المواعيد</a>
      <a href="<?= url('provider_money') ?>">الأرباح والترقية</a>
      <span class="role-chip provider-chip">مقدم خدمة</span>
      <form method="post" action="actions.php" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="logout"><button class="link-button" type="submit">خروج</button></form>
    <?php else: ?>
      <a href="<?= url('admin_dashboard') ?>">الرئيسية</a>
      <a href="<?= url('admin_users') ?>">المستخدمون</a>
      <a href="<?= url('admin_providers') ?>">مقدمو الخدمة</a>
      <a href="<?= url('admin_bookings') ?>">الحجوزات</a>
      <a href="<?= url('admin_money') ?>">المالية</a>
      <a href="<?= url('admin_ads') ?>">الإعلانات</a>
      <a href="<?= url('admin_disputes') ?>">الشكاوى</a>
      <span class="role-chip admin-chip">إدارة</span>
      <form method="post" action="actions.php" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="logout"><button class="link-button" type="submit">خروج</button></form>
    <?php endif; ?>
  </nav>
</header>
<?php if ($user): ?>
  <div class="portal-strip <?= e($role) ?>-strip">
    <div class="container portal-strip-inner">
      <div><strong><?= e($roleLabels[$role]) ?></strong><span>مرحباً، <?= e($user['name']) ?></span></div>
      <?php if ($role === 'provider' && $user['status'] !== 'active'): ?><span class="status-note">الحساب بانتظار موافقة الإدارة</span><?php endif; ?>
      <?php if ($role === 'admin'): ?><span class="status-note">الحساب الإداري مخفي عن التسجيل العام</span><?php endif; ?>
    </div>
  </div>
<?php endif; ?>
<?php foreach (flashes() as $flash): ?>
  <div class="container"><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div></div>
<?php endforeach; ?>
