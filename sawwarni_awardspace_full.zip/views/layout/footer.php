<footer class="footer">
  <div class="container footer-grid">
    <div>
      <div class="brand footer-brand"><span class="logo-mark">ص</span><span>صورني</span></div>
      <p>منصة عراقية لحجز المصورين، الفيديو، الدرون، الاستوديو والمونتاج.</p>
    </div>
    <div>
      <strong>نموذج الدخل</strong>
      <p>عمولة الحجوزات: <?= e(setting('commission_percent', '10')) ?>%</p>
      <p>رسوم الحجز العاجل: <?= format_iqd(setting('urgent_fee', '10000')) ?></p>
    </div>
    <div>
      <strong>روابط سريعة</strong>
      <p><a href="<?= url('providers') ?>">عرض مقدمي الخدمة</a></p>
      <p><a href="<?= url('register',['type'=>'provider']) ?>">الانضمام كمقدم خدمة</a></p>
    </div>
  </div>
  <div class="container footer-bottom">نسخة اختبار حقيقية — PHP/MySQL</div>
</footer>
<script src="assets/js/app.js"></script>
</body>
</html>
