<?php
declare(strict_types=1);

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    static $user = null;
    if ($user && (int)$user['id'] === (int)$_SESSION['user_id']) {
        return $user;
    }
    $user = fetch_one('SELECT * FROM users WHERE id = ?', [$_SESSION['user_id']]);
    return $user ?: null;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function has_role(string $role): bool
{
    $user = current_user();
    return $user && $user['role'] === $role;
}

function require_auth(): void
{
    if (!is_logged_in()) {
        flash('warning', 'Please login first.');
        redirect('login');
    }
}

function require_role(string $role): void
{
    require_auth();
    if (!has_role($role)) {
        http_response_code(403);
        exit('Forbidden.');
    }
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
