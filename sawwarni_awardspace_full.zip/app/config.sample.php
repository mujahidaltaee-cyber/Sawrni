<?php
// Copy this file to config.php manually, or run setup.php once.
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'sawwarni');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_URL', 'http://localhost/sawwarni');
define('APP_NAME', 'صورني');
define('APP_ENV', 'production');
