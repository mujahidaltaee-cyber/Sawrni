<?php
declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function short_text(?string $value, int $length = 120): string
{
    $value = trim((string)$value);
    if (function_exists('mb_strimwidth')) {
        return mb_strimwidth($value, 0, $length, '...', 'UTF-8');
    }
    return strlen($value) > $length ? substr($value, 0, $length - 3) . '...' : $value;
}

function url(string $page = 'home', array $params = []): string
{
    $params = array_merge(['page' => $page], $params);
    return 'index.php?' . http_build_query($params);
}

function asset(string $path): string
{
    return ltrim($path, '/');
}

function redirect(string $page, array $params = []): void
{
    header('Location: ' . url($page, $params));
    exit;
}

function redirect_raw(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $sent = $_POST['csrf_token'] ?? '';
    if (!$sent || !hash_equals($_SESSION['csrf_token'] ?? '', $sent)) {
        http_response_code(419);
        exit('Invalid CSRF token. Refresh the page and try again.');
    }
}

function format_iqd($amount): string
{
    return number_format((float)$amount, 0) . ' IQD';
}

function setting(string $key, $default = null)
{
    try {
        $row = fetch_one('SELECT setting_value FROM settings WHERE setting_key = ?', [$key]);
        return $row['setting_value'] ?? $default;
    } catch (Throwable $e) {
        return $default;
    }
}

function calculate_money(float $total): array
{
    $commissionPercent = (float) setting('commission_percent', '10');
    $commission = round($total * ($commissionPercent / 100));
    return [
        'commission_percent' => $commissionPercent,
        'app_commission' => $commission,
        'provider_amount' => $total - $commission,
    ];
}

function booking_code(): string
{
    return 'SOR-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
}

function status_badge(string $status): string
{
    $labels = [
        'active' => 'فعال', 'pending' => 'قيد الانتظار', 'blocked' => 'موقوف', 'rejected' => 'مرفوض',
        'accepted' => 'مقبول', 'awaiting_payment' => 'بانتظار الدفع', 'confirmed' => 'مؤكد',
        'in_progress' => 'قيد التنفيذ', 'completed' => 'مكتمل', 'cancelled' => 'ملغي',
        'refunded' => 'مسترجع', 'disputed' => 'توجد شكوى', 'unpaid' => 'غير مدفوع',
        'deposit_paid' => 'العربون مدفوع', 'paid' => 'مدفوع', 'provider_paid' => 'تم دفع المستحق',
        'expired' => 'منتهي', 'open' => 'مفتوحة', 'under_review' => 'قيد المراجعة',
        'resolved' => 'محلولة', 'failed' => 'فشل', 'approved' => 'موثق', 'none' => 'بدون اشتراك'
    ];
    $class = 'badge';
    if (in_array($status, ['completed', 'paid', 'active', 'approved', 'confirmed', 'provider_paid', 'resolved'], true)) {
        $class .= ' badge-green';
    } elseif (in_array($status, ['pending', 'awaiting_payment', 'in_progress', 'under_review', 'deposit_paid', 'open'], true)) {
        $class .= ' badge-yellow';
    } elseif (in_array($status, ['cancelled', 'rejected', 'refunded', 'disputed', 'blocked', 'failed'], true)) {
        $class .= ' badge-red';
    } else {
        $class .= ' badge-gray';
    }
    return '<span class="' . $class . '">' . e($labels[$status] ?? str_replace('_', ' ', $status)) . '</span>';
}

function upload_media(array $file, string $subdir = 'portfolio'): ?string
{
    if (empty($file['name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'mp4', 'mov', 'webm'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        throw new RuntimeException('File type is not allowed.');
    }

    if (($file['size'] ?? 0) > 25 * 1024 * 1024) {
        throw new RuntimeException('Maximum upload size is 25MB.');
    }

    $targetDir = UPLOAD_DIR . '/' . trim($subdir, '/');
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $filename = date('YmdHis') . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
    $target = $targetDir . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        throw new RuntimeException('Failed to upload file.');
    }

    return 'uploads/' . trim($subdir, '/') . '/' . $filename;
}

function is_video(string $path): bool
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    return in_array($ext, ['mp4', 'mov', 'webm'], true);
}

function log_audit(string $action, string $entityType = '', ?int $entityId = null, string $details = ''): void
{
    try {
        $user = current_user();
        execute_sql(
            'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
            [$user['id'] ?? null, $action, $entityType, $entityId, $details, $_SERVER['REMOTE_ADDR'] ?? '']
        );
    } catch (Throwable $e) {
        // Audit logging must never break the app.
    }
}

function require_method_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Method not allowed.');
    }
}
