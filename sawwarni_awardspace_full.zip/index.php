<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';

$page = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['page'] ?? 'home');
$publicPages = ['home', 'login', 'customer_login', 'provider_login', 'register', 'providers', 'provider'];

if (!in_array($page, $publicPages, true) && !is_logged_in()) {
    flash('warning', 'Please login first.');
    redirect('login');
}

$protectedByRole = [
    'customer_dashboard' => 'customer',
    'customer_profile' => 'customer',
    'book' => 'customer',
    'provider_dashboard' => 'provider',
    'provider_profile' => 'provider',
    'provider_packages' => 'provider',
    'provider_portfolio' => 'provider',
    'provider_availability' => 'provider',
    'provider_money' => 'provider',
    'admin_dashboard' => 'admin',
    'admin_users' => 'admin',
    'admin_providers' => 'admin',
    'admin_categories' => 'admin',
    'admin_bookings' => 'admin',
    'admin_money' => 'admin',
    'admin_ads' => 'admin',
    'admin_disputes' => 'admin',
    'admin_audit' => 'admin',
];

if (isset($protectedByRole[$page])) {
    require_role($protectedByRole[$page]);
}

$viewPath = __DIR__ . '/views/pages/' . $page . '.php';
if (!file_exists($viewPath)) {
    http_response_code(404);
    $pageTitle = 'Page not found';
    require __DIR__ . '/views/layout/header.php';
    echo '<section class="container"><div class="card"><h1>404</h1><p>Page not found.</p></div></section>';
    require __DIR__ . '/views/layout/footer.php';
    exit;
}

require $viewPath;
