<?php
declare(strict_types=1);

function setup_e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$configFile = __DIR__ . '/app/config.php';
$installed = file_exists($configFile);
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
    $dbHost = trim($_POST['db_host'] ?? 'localhost');
    $dbPort = trim($_POST['db_port'] ?? '3306');
    $dbName = trim($_POST['db_name'] ?? '');
    $dbUser = trim($_POST['db_user'] ?? '');
    $dbPass = (string)($_POST['db_pass'] ?? '');
    $appUrl = rtrim(trim($_POST['app_url'] ?? ''), '/');
    $seedDemo = !empty($_POST['seed_demo']);

    if ($dbHost === '' || $dbName === '' || $dbUser === '') {
        $errors[] = 'أدخل معلومات قاعدة البيانات كاملة.';
    }

    if (!$errors) {
        try {
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $dbHost, $dbPort, $dbName);
            $pdo = new PDO($dsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);

            $schema = file_get_contents(__DIR__ . '/database/schema.sql');
            if ($schema === false) {
                throw new RuntimeException('تعذر قراءة ملف قاعدة البيانات.');
            }
            $statements = preg_split('/;\s*(?:\r?\n|$)/', $schema);
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if ($statement !== '') {
                    $pdo->exec($statement);
                }
            }

            // Fixed hidden management account requested by the owner.
            $managementHash = password_hash('123456', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                'INSERT INTO users (name, username, email, phone, password_hash, role, status)
                 VALUES (?, ?, ?, ?, ?, "admin", "active")
                 ON DUPLICATE KEY UPDATE name=VALUES(name), username=VALUES(username), password_hash=VALUES(password_hash), role="admin", status="active"'
            );
            $stmt->execute(['Mujahid', 'Mujahid', 'management@sawwarni.local', '', $managementHash]);

            if ($seedDemo) {
                $customerHash = password_hash('123456', PASSWORD_DEFAULT);
                $providerHash = password_hash('123456', PASSWORD_DEFAULT);

                $stmt = $pdo->prepare(
                    'INSERT INTO users (name, email, phone, password_hash, role, status)
                     VALUES (?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE name=VALUES(name), phone=VALUES(phone), password_hash=VALUES(password_hash), status=VALUES(status)'
                );
                $stmt->execute(['عميل تجريبي', 'customer@sawwarni.test', '07700000001', $customerHash, 'customer', 'active']);
                $stmt->execute(['علي المصور', 'provider@sawwarni.test', '07700000002', $providerHash, 'provider', 'active']);

                $providerUser = $pdo->query("SELECT id FROM users WHERE email='provider@sawwarni.test' LIMIT 1")->fetch();
                if ($providerUser) {
                    $stmt = $pdo->prepare(
                        'INSERT INTO provider_profiles (user_id, business_name, bio, city, area, instagram_url, equipment, verified, rating)
                         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 4.80)
                         ON DUPLICATE KEY UPDATE business_name=VALUES(business_name), bio=VALUES(bio), city=VALUES(city), area=VALUES(area), equipment=VALUES(equipment), verified=1, rating=4.80'
                    );
                    $stmt->execute([
                        (int)$providerUser['id'],
                        'Ali Photography',
                        'تصوير تخرج، مناسبات، ريلز وتصوير منتجات داخل بغداد.',
                        'بغداد',
                        'المنصور',
                        '',
                        'Canon R6، عدسة 24-70، إضاءة متنقلة، مثبت فيديو',
                    ]);
                    $providerId = (int)$pdo->query('SELECT id FROM provider_profiles WHERE user_id=' . (int)$providerUser['id'])->fetchColumn();
                    foreach ([1, 4, 5, 6] as $categoryId) {
                        $pdo->prepare('INSERT IGNORE INTO provider_categories (provider_id, category_id) VALUES (?, ?)')->execute([$providerId, $categoryId]);
                    }
                    $count = (int)$pdo->query('SELECT COUNT(*) FROM packages WHERE provider_id=' . $providerId)->fetchColumn();
                    if ($count === 0) {
                        $packages = [
                            [1, 'باقة تخرج أساسية', 'جلسة لمدة ساعة، 20 صورة معدلة، موقع واحد، تسليم خلال 3 أيام.', 75000, 60, 3, 0, 0, 0],
                            [1, 'باقة تخرج بريميوم', 'ساعتان، 35 صورة معدلة، فيديو Reel قصير، موقعان.', 150000, 120, 4, 0, 1, 1],
                            [6, 'تصوير Reel للمشاريع', 'تصوير ومونتاج فيديو عمودي قصير مناسب للسوشيال ميديا.', 125000, 90, 4, 0, 1, 1],
                        ];
                        $ps = $pdo->prepare('INSERT INTO packages (provider_id, category_id, title, description, price, duration_minutes, delivery_days, includes_drone, includes_video, is_premium, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active")');
                        foreach ($packages as $pack) {
                            $ps->execute(array_merge([$providerId], $pack));
                        }
                    }
                    $countAvailability = (int)$pdo->query('SELECT COUNT(*) FROM availability WHERE provider_id=' . $providerId)->fetchColumn();
                    if ($countAvailability === 0) {
                        $av = $pdo->prepare('INSERT INTO availability (provider_id, day_of_week, start_time, end_time, is_available) VALUES (?, ?, ?, ?, 1)');
                        foreach ([0,1,2,3,4,6] as $day) {
                            $av->execute([$providerId, $day, '09:00:00', '20:00:00']);
                        }
                    }
                }
            }

            $config = "<?php\n";
            $config .= "define('DB_HOST', " . var_export($dbHost, true) . ");\n";
            $config .= "define('DB_PORT', " . var_export($dbPort, true) . ");\n";
            $config .= "define('DB_NAME', " . var_export($dbName, true) . ");\n";
            $config .= "define('DB_USER', " . var_export($dbUser, true) . ");\n";
            $config .= "define('DB_PASS', " . var_export($dbPass, true) . ");\n";
            $config .= "define('APP_URL', " . var_export($appUrl, true) . ");\n";
            $config .= "define('APP_NAME', 'صورني');\n";
            $config .= "define('APP_ENV', 'production');\n";

            if (file_put_contents($configFile, $config, LOCK_EX) === false) {
                throw new RuntimeException('تعذر كتابة app/config.php. تأكد من صلاحيات الكتابة للمجلد app.');
            }

            $success = true;
            $installed = true;
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>تثبيت صورني</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="setup-body">
<main class="setup-card">
  <div class="brand setup-brand"><span class="logo-mark">ص</span><span>صورني</span></div>
  <h1>تثبيت نسخة AwardSpace</h1>
  <p class="muted">أدخل بيانات MySQL التي أنشأتها من لوحة الاستضافة. حساب الإدارة يُنشأ تلقائياً ولا يظهر ضمن أنواع التسجيل.</p>

  <?php if ($installed && !$success): ?>
    <div class="alert success">الموقع مثبت مسبقاً. احذف ملف <code>setup.php</code> بعد التأكد من التشغيل.</div>
    <a class="btn primary" href="index.php">فتح الموقع</a>
  <?php elseif ($success): ?>
    <div class="alert success">
      <strong>تم التثبيت بنجاح.</strong><br>
      مسار الإدارة المخفي: <code>management.php</code><br>
      اسم المستخدم: <code>Mujahid</code><br>
      كلمة المرور: <code>123456</code>
    </div>
    <div class="alert warning">احذف <code>setup.php</code> من الاستضافة بعد التثبيت. غيّر كلمة مرور الإدارة قبل استخدام الموقع مع بيانات أو أموال حقيقية.</div>
    <a class="btn primary" href="index.php">فتح الموقع</a>
  <?php else: ?>
    <?php foreach ($errors as $error): ?><div class="alert danger"><?= setup_e($error) ?></div><?php endforeach; ?>
    <form method="post" class="grid-form">
      <h2>قاعدة البيانات</h2>
      <label>Database Host<input name="db_host" value="<?= setup_e($_POST['db_host'] ?? 'localhost') ?>" required></label>
      <div class="form-row">
        <label>Port<input name="db_port" value="<?= setup_e($_POST['db_port'] ?? '3306') ?>" required></label>
        <label>Database Name<input name="db_name" value="<?= setup_e($_POST['db_name'] ?? '') ?>" required></label>
      </div>
      <label>Database User<input name="db_user" value="<?= setup_e($_POST['db_user'] ?? '') ?>" required></label>
      <label>Database Password<input name="db_pass" type="password"></label>
      <label>رابط الموقع الكامل<input name="app_url" value="<?= setup_e($_POST['app_url'] ?? '') ?>" placeholder="https://example.atwebpages.com"></label>
      <label class="check-line"><input type="checkbox" name="seed_demo" value="1" checked> إضافة مصور وعميل تجريبيين لتجربة سير العمل فوراً</label>
      <button class="btn primary" type="submit">تثبيت الموقع</button>
    </form>
  <?php endif; ?>
</main>
</body>
</html>
