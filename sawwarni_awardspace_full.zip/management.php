<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';

if (is_logged_in() && has_role('admin')) {
    redirect('admin_dashboard');
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>إدارة صورني</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="management-body">
  <main class="management-login-card">
    <div class="brand"><span class="logo-mark">ص</span><span>صورني</span></div>
    <div class="management-seal">إدارة النظام</div>
    <h1>الدخول الإداري</h1>
    <p class="muted">هذه الصفحة غير ظاهرة ضمن واجهة العملاء أو مقدمي الخدمة.</p>
    <?php foreach (flashes() as $flash): ?>
      <div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
    <?php endforeach; ?>
    <form class="grid-form" method="post" action="actions.php" autocomplete="off">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="management_login">
      <label>اسم المستخدم<input name="username" required autofocus></label>
      <label>كلمة المرور<input type="password" name="password" required></label>
      <button class="btn primary" type="submit">دخول الإدارة</button>
    </form>
    <a class="subtle-link" href="index.php">العودة إلى الموقع</a>
  </main>
</body>
</html>
