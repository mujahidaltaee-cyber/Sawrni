<?php
$id = (int)($_GET['id'] ?? 0);
$provider = fetch_one('SELECT pp.*, u.name, u.phone, u.email FROM provider_profiles pp JOIN users u ON u.id=pp.user_id WHERE pp.id=? AND u.status="active"', [$id]);
if (!$provider) { http_response_code(404); $pageTitle='غير موجود'; require APP_ROOT.'/views/layout/header.php'; echo '<section class="section"><div class="container"><div class="card empty"><h1>المصور غير موجود</h1></div></div></section>'; require APP_ROOT.'/views/layout/footer.php'; return; }
$packages = fetch_all('SELECT p.*, c.name_ar, c.icon FROM packages p JOIN categories c ON c.id=p.category_id WHERE p.provider_id=? AND p.status="active" ORDER BY p.is_premium DESC, p.price', [$id]);
$portfolio = fetch_all('SELECT * FROM portfolios WHERE provider_id=? ORDER BY id DESC LIMIT 24', [$id]);
$reviews = fetch_all('SELECT r.*, u.name FROM reviews r JOIN users u ON u.id=r.customer_id WHERE r.provider_id=? ORDER BY r.id DESC LIMIT 8', [$id]);
$availability = fetch_all('SELECT * FROM availability WHERE provider_id=? ORDER BY day_of_week', [$id]);
$days=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
$fallback='assets/img/demo/avatar-ali.jpg';
$portfolioFallbacks=[demo_photo('photo-1689785380577-93f35f4d6bf9'),demo_photo('photo-1759054710581-c7745b02cb53'),demo_photo('photo-1502982720700-bfff97f2ecac'),demo_photo('photo-1516035069371-29a1b244cc32')];
$pageTitle = $provider['business_name'];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="provider-profile-hero">
    <img src="<?= e($portfolio[0]['file_url'] ?? demo_photo('photo-1502982720700-bfff97f2ecac')) ?>" alt="">
    <div class="provider-profile-info"><div class="provider-head"><img class="avatar" src="<?= e($provider['profile_image'] ?: $fallback) ?>" alt=""><div><div class="pill-row"><span class="badge badge-green"><?= $provider['verified']?'✓ حساب موثق':'مقدم خدمة' ?></span><?php if($provider['featured_until'] && $provider['featured_until']>=date('Y-m-d')): ?><span class="badge badge-yellow">★ مميز</span><?php endif; ?></div><h1 style="font-size:clamp(2rem,4vw,3.5rem);margin:.45rem 0"><?= e($provider['business_name']) ?></h1><div>📍 <?= e($provider['city']) ?><?= $provider['area']?' — '.e($provider['area']):'' ?> &nbsp; • &nbsp; ⭐ <?= e((string)$provider['rating']) ?> &nbsp; • &nbsp; <?= (int)$provider['total_bookings'] ?> حجز</div></div></div><a class="btn gold large" href="#packages">عرض الباقات</a></div>
  </div>
</div></section>

<section class="section"><div class="container grid grid-3" style="align-items:start">
  <div class="card" style="grid-column:span 2"><span class="eyebrow">About creator</span><h2>عن مقدم الخدمة</h2><p><?= nl2br(e($provider['bio'])) ?></p><div class="divider"></div><h3>المعدات والخبرة</h3><p class="muted"><?= nl2br(e($provider['equipment'])) ?></p><?php if($provider['instagram_url']): ?><a class="btn" target="_blank" href="<?= e($provider['instagram_url']) ?>">فتح Instagram ↗</a><?php endif; ?></div>
  <div class="card sticky-booking"><span class="eyebrow">Availability</span><h2>الأوقات المتاحة</h2><div class="booking-list"><?php foreach($availability as $a): ?><div class="booking-card" style="grid-template-columns:1fr auto;padding:12px"><strong><?= e($days[(int)$a['day_of_week']]) ?></strong><span class="badge badge-gray"><?= e(substr($a['start_time'],0,5)) ?> — <?= e(substr($a['end_time'],0,5)) ?></span></div><?php endforeach; ?><?php if(!$availability): ?><p class="muted">لم يحدد المصور أوقاتاً بعد.</p><?php endif; ?></div></div>
</div></section>

<section class="section" id="packages"><div class="container">
  <div class="section-title"><div><span class="eyebrow">Choose a package</span><h2>الباقات المتاحة</h2><p class="muted">الأسعار والمخرجات ومدة التسليم موضحة قبل الحجز.</p></div></div>
  <div class="grid grid-3">
    <?php foreach($packages as $p): ?>
      <div class="card package-card <?= $p['is_premium']?'premium':'' ?>"><?php if($p['is_premium']): ?><span class="package-ribbon">PREMIUM</span><?php endif; ?><span class="badge badge-gray"><?= e($p['icon'].' '.$p['name_ar']) ?></span><h3><?= e($p['title']) ?></h3><p class="muted"><?= nl2br(e($p['description'])) ?></p><div class="package-features"><span><?= (int)$p['duration_minutes'] ?> دقيقة تصوير</span><span>التسليم خلال <?= (int)$p['delivery_days'] ?> أيام</span><?php if($p['includes_video']): ?><span>فيديو أو Reel مشمول</span><?php endif; ?><?php if($p['includes_drone']): ?><span>تصوير درون مشمول</span><?php endif; ?></div><p class="price"><?= format_iqd($p['price']) ?></p><?php if(is_logged_in() && has_role('customer')): ?><a class="btn primary block" href="<?= url('book',['package_id'=>$p['id']]) ?>">احجز هذه الباقة</a><?php elseif(!is_logged_in()): ?><a class="btn primary block" href="<?= url('customer_login') ?>">سجل للدخول والحجز</a><?php endif; ?></div>
    <?php endforeach; ?>
    <?php if(!$packages): ?><div class="card empty">لا توجد باقات مفعّلة.</div><?php endif; ?>
  </div>
</div></section>

<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">Portfolio</span><h2>معرض الأعمال</h2></div></div><div class="portfolio-grid">
  <?php foreach($portfolio as $i=>$item): ?><div class="portfolio-item"><?php if($item['media_type']==='video'): ?><video controls src="<?= e($item['file_url']) ?>"></video><?php else: ?><img loading="lazy" src="<?= e($item['file_url'] ?: $portfolioFallbacks[$i%count($portfolioFallbacks)]) ?>" alt="<?= e($item['caption']) ?>"><?php endif; ?><div class="portfolio-item-caption"><?= e($item['caption']) ?></div></div><?php endforeach; ?>
  <?php if(!$portfolio): ?><?php foreach($portfolioFallbacks as $img): ?><div class="portfolio-item"><img loading="lazy" src="<?= e($img) ?>" alt="عمل تجريبي"><div class="portfolio-item-caption">عمل تجريبي للعرض</div></div><?php endforeach; ?><?php endif; ?>
</div></div></section>

<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">Reviews</span><h2>آراء العملاء</h2></div><span class="role-chip provider-chip">⭐ <?= e((string)$provider['rating']) ?></span></div><div class="grid grid-2">
  <?php foreach($reviews as $r): ?><div class="testimonial"><div class="testimonial-stars"><?= str_repeat('★',(int)$r['rating']) ?></div><p>“<?= nl2br(e($r['comment'])) ?>”</p><div class="testimonial-author"><img src="<?= e(demo_photo('photo-1494790108377-be9c29b29330',240,240)) ?>"><div><strong><?= e($r['name']) ?></strong><div class="mini muted">حجز مكتمل</div></div></div></div><?php endforeach; ?>
  <?php if(!$reviews): ?><div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“تجربة تجريبية ممتازة، الموعد كان واضحاً والتواصل من داخل الحجز سهل.”</p><div class="testimonial-author"><img src="<?= e(demo_photo('photo-1494790108377-be9c29b29330',240,240)) ?>"><div><strong>عميلة صورني</strong><div class="mini muted">تقييم تجريبي</div></div></div></div><?php endif; ?>
</div></div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
