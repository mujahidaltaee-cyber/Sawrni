<?php
$pageTitle = 'لوحة العميل';
$user = current_user();
$bookings = fetch_all('SELECT b.*, p.title AS package_title, pp.business_name, pp.profile_image FROM bookings b JOIN packages p ON p.id=b.package_id JOIN provider_profiles pp ON pp.id=b.provider_id WHERE b.customer_id=? ORDER BY b.id DESC',[$user['id']]);
$stats=['all'=>count($bookings),'active'=>count(array_filter($bookings,fn($b)=>in_array($b['status'],['pending','accepted','awaiting_payment','confirmed','in_progress'],true))),'completed'=>count(array_filter($bookings,fn($b)=>$b['status']==='completed')),'spent'=>array_sum(array_map(fn($b)=>in_array($b['payment_status'],['paid','provider_paid'],true)?(float)$b['total_price']:0,$bookings))];
$activeBookings=array_values(array_filter($bookings,fn($b)=>in_array($b['status'],['pending','accepted','awaiting_payment','confirmed','in_progress'],true)));
$customerAds=fetch_all('SELECT * FROM ads WHERE status="active" AND (placement="home" OR placement="all" OR placement="booking") AND (starts_at IS NULL OR starts_at <= CURDATE()) AND (ends_at IS NULL OR ends_at >= CURDATE()) ORDER BY id DESC LIMIT 3');
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title"><div><span class="eyebrow">Customer portal</span><h1 style="font-size:clamp(2.2rem,4vw,3.8rem)">مرحباً، <?= e($user['name']) ?></h1><p class="muted">كل حجوزاتك، المدفوعات والمحادثات في مكان واحد.</p></div><a class="btn customer-btn large" href="<?= url('providers') ?>">＋ حجز خدمة جديدة</a></div>
  <div class="dash-grid"><div class="metric"><div class="metric-icon">▣</div><span>كل الحجوزات</span><strong><?= (int)$stats['all'] ?></strong></div><div class="metric"><div class="metric-icon">⚡</div><span>الحجوزات الفعالة</span><strong><?= (int)$stats['active'] ?></strong></div><div class="metric"><div class="metric-icon">✓</div><span>المكتملة</span><strong><?= (int)$stats['completed'] ?></strong></div><div class="metric"><div class="metric-icon">◈</div><span>إجمالي المدفوع</span><strong><?= format_iqd($stats['spent']) ?></strong></div></div>

  <?php if($customerAds): ?>
  <div class="customer-sponsored" style="margin-top:22px">
    <div class="section-title"><div><span class="eyebrow">Sponsored for you</span><h2>عروض مقترحة لجلستك القادمة</h2></div><a class="btn small" href="<?= url('home') ?>">كل العروض</a></div>
    <div class="grid grid-3">
      <?php foreach($customerAds as $ad): ?>
        <a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank">
          <span class="ad-label">إعلان ممول</span>
          <img loading="lazy" src="<?= e($ad['image_url'] ?: demo_photo('photo-1502982720700-bfff97f2ecac')) ?>" alt="<?= e($ad['title']) ?>">
          <strong><?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="grid grid-3" style="margin-top:22px;align-items:start">
    <div class="card" style="grid-column:span 2"><div class="section-title"><div><h2>الحجوزات الحالية</h2><p class="muted">تابع آخر تحديثات طلباتك.</p></div></div><div class="booking-list">
      <?php foreach(array_slice($activeBookings,0,5) as $b): ?><div class="booking-card"><div class="booking-date"><div><?= date('d',strtotime($b['booking_date'])) ?></div><span class="mini"><?= date('M',strtotime($b['booking_date'])) ?></span></div><div><div class="pill-row"><h3><?= e($b['package_title']) ?></h3><?= $b['urgent']?'<span class="badge badge-yellow">عاجل</span>':'' ?></div><p class="muted"><?= e($b['business_name']) ?> • <?= e(substr($b['start_time'],0,5)) ?> • <?= e($b['location']) ?></p><div class="pill-row"><?= status_badge($b['status']) ?><?= status_badge($b['payment_status']) ?></div></div><div class="booking-actions"><a class="btn small" href="<?= url('messages',['booking_id'=>$b['id']]) ?>">فتح الحجز</a></div></div><?php endforeach; ?>
      <?php if(!$activeBookings): ?><div class="empty"><h3>لا توجد حجوزات فعالة</h3><p>ابدأ باختيار مصور أو خدمة مناسبة.</p><a class="btn customer-btn" href="<?= url('providers') ?>">استكشف الخدمات</a></div><?php endif; ?>
    </div></div>
    <div class="card"><span class="eyebrow">Quick actions</span><h2>اختصارات</h2><div class="grid-form"><a class="btn block" href="<?= url('providers',['category_id'=>1]) ?>">🎓 جلسة تخرج</a><a class="btn block" href="<?= url('providers',['category_id'=>3]) ?>">🚁 تصوير درون</a><a class="btn block" href="<?= url('providers',['category_id'=>6]) ?>">🎬 تصوير Reel</a><a class="btn block" href="<?= url('customer_profile') ?>">⚙ تعديل بيانات الحساب</a></div><div class="divider"></div><img src="<?= e(demo_photo('photo-1689785380577-93f35f4d6bf9')) ?>" style="height:170px;width:100%;object-fit:cover;border-radius:17px" alt=""></div>
  </div>

  <div class="card" style="margin-top:22px"><div class="section-title"><div><h2>سجل الحجوزات الكامل</h2><p class="muted">تفاصيل الحالة والدفع لكل طلب.</p></div><a class="btn small" href="<?= url('customer_profile') ?>">بيانات الحساب</a></div><div class="table-wrap"><table><thead><tr><th>رقم الحجز</th><th>مقدم الخدمة</th><th>الباقة</th><th>الموعد</th><th>الإجمالي</th><th>الحالة</th><th>الدفع</th><th>الإجراءات</th></tr></thead><tbody>
    <?php foreach($bookings as $b): ?><tr><td><strong><?= e($b['booking_code']) ?></strong><?php if($b['urgent']): ?><br><span class="badge badge-yellow">عاجل</span><?php endif; ?></td><td><?= e($b['business_name']) ?></td><td><?= e($b['package_title']) ?></td><td><?= e($b['booking_date'].' '.substr($b['start_time'],0,5)) ?></td><td><?= format_iqd($b['total_price']) ?></td><td><?= status_badge($b['status']) ?></td><td><?= status_badge($b['payment_status']) ?></td><td><a class="btn small" href="<?= url('messages',['booking_id'=>$b['id']]) ?>">تفاصيل ومحادثة</a></td></tr><?php if($b['status']==='completed'): ?><tr><td colspan="8"><form method="post" action="actions.php" class="form-row"><?= csrf_field() ?><input type="hidden" name="action" value="review_create"><input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>"><label>التقييم<select name="rating"><option value="5">5 نجوم</option><option value="4">4 نجوم</option><option value="3">3 نجوم</option><option value="2">نجمتان</option><option value="1">نجمة واحدة</option></select></label><label>التعليق<input name="comment" placeholder="شارك رأيك بالخدمة"></label><button class="btn green" type="submit">إرسال التقييم</button></form></td></tr><?php endif; ?><?php endforeach; ?>
    <?php if(!$bookings): ?><tr><td colspan="8" class="empty">لا توجد حجوزات بعد.</td></tr><?php endif; ?>
  </tbody></table></div></div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
