<?php
$pageTitle='الإعلانات';
$ads=fetch_all('SELECT a.*, c.name_ar FROM ads a LEFT JOIN categories c ON c.id=a.category_id ORDER BY a.id DESC');
$categories=fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order');
$edit=null;
if(!empty($_GET['edit'])) $edit=fetch_one('SELECT * FROM ads WHERE id=?',[(int)$_GET['edit']]);
$defaults=[
  'starts_at'=>date('Y-m-d'),
  'ends_at'=>date('Y-m-d',strtotime('+30 days')),
  'placement'=>'all',
  'status'=>'active',
  'price'=>0,
  'city'=>'بغداد',
];
$form=array_merge($defaults,$edit?:[]);
require APP_ROOT.'/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title">
    <div><span class="eyebrow">Ad manager</span><h1>الإعلانات داخل صورني</h1><p class="muted">أي إعلان بحالة “فعال” وتاريخ صالح سيظهر فوراً للعميل في المكان المحدد.</p></div>
    <div class="pill-row"><a class="btn" target="_blank" href="<?= url('home') ?>">معاينة الرئيسية</a><a class="btn" target="_blank" href="<?= url('providers') ?>">معاينة صفحة المصورين</a></div>
  </div>

  <div class="admin-ad-layout">
    <div class="card">
      <div class="section-title"><div><h2><?= $edit?'تعديل الإعلان':'إضافة إعلان جديد' ?></h2><p class="muted">يمكن رفع صورة أو لصق رابط صورة خارجي. الرفع له الأولوية.</p></div><?php if($edit): ?><a class="btn small" href="<?= url('admin_ads') ?>">إعلان جديد</a><?php endif; ?></div>
      <form class="grid-form" method="post" action="actions.php" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="admin_ad_save">
        <input type="hidden" name="id" value="<?= e($edit['id']??'') ?>">
        <label>اسم المعلن<input name="advertiser_name" value="<?= e($form['advertiser_name']??'') ?>" placeholder="مثال: Baghdad Camera House" required></label>
        <label>عنوان الإعلان<input name="title" value="<?= e($form['title']??'') ?>" placeholder="مثال: خصم 15% على الإضاءة" required></label>
        <label>رابط عند الضغط<input name="target_url" value="<?= e($form['target_url']??'') ?>" placeholder="https://..."></label>
        <label>رابط صورة خارجي — اختياري<input name="image_url" value="<?= e($form['image_url']??'') ?>" placeholder="https://images..."></label>
        <label>أو ارفع صورة من الجهاز<input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></label>
        <?php if(!empty($form['image_url'])): ?><div class="ad-admin-preview"><img src="<?= e($form['image_url']) ?>" alt=""><span>الصورة الحالية</span></div><?php endif; ?>
        <div class="form-row">
          <label>التصنيف<select name="category_id"><option value="">عام</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= !empty($form['category_id']) && (int)$form['category_id']===(int)$c['id']?'selected':'' ?>><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select></label>
          <label>المدينة<input name="city" value="<?= e($form['city']??'بغداد') ?>"></label>
        </div>
        <div class="form-row"><label>يبدأ من<input type="date" name="starts_at" value="<?= e($form['starts_at']) ?>"></label><label>ينتهي في<input type="date" name="ends_at" value="<?= e($form['ends_at']) ?>"></label></div>
        <div class="form-row">
          <label>سعر الإعلان<input type="number" min="0" step="1000" name="price" value="<?= e((string)$form['price']) ?>"></label>
          <label>مكان الظهور<select name="placement"><option value="all" <?= $form['placement']==='all'?'selected':'' ?>>كل أماكن العملاء</option><option value="home" <?= $form['placement']==='home'?'selected':'' ?>>الرئيسية فقط</option><option value="category" <?= $form['placement']==='category'?'selected':'' ?>>صفحة المصورين</option><option value="booking" <?= $form['placement']==='booking'?'selected':'' ?>>صفحة الحجز</option></select></label>
        </div>
        <label>الحالة<select name="status"><option value="active" <?= $form['status']==='active'?'selected':'' ?>>فعال — يظهر للعملاء</option><option value="pending" <?= $form['status']==='pending'?'selected':'' ?>>قيد الانتظار — مخفي</option><option value="expired" <?= $form['status']==='expired'?'selected':'' ?>>منتهي</option><option value="cancelled" <?= $form['status']==='cancelled'?'selected':'' ?>>ملغي</option></select></label>
        <div class="alert success">الإعداد الافتراضي الآن هو: فعال، يظهر في جميع صفحات العملاء، من اليوم ولمدة 30 يوماً.</div>
        <button class="btn primary large" type="submit">حفظ ونشر الإعلان</button>
      </form>
    </div>

    <div class="card">
      <div class="section-title"><div><h2>الإعلانات الحالية</h2><p class="muted"><?= count($ads) ?> إعلان مسجل</p></div></div>
      <div class="admin-ad-list">
        <?php foreach($ads as $a): $visible=ad_is_visible($a); ?>
          <article class="admin-ad-item <?= $visible?'is-live':'is-hidden' ?>">
            <img src="<?= e($a['image_url'] ?: demo_photo('photo-1502982720700-bfff97f2ecac')) ?>" alt="">
            <div class="admin-ad-info">
              <div class="pill-row"><strong><?= e($a['title']) ?></strong><?= $visible?'<span class="badge badge-green">ظاهر للعملاء الآن</span>':'<span class="badge badge-red">غير ظاهر</span>' ?></div>
              <p class="muted"><?= e($a['advertiser_name']) ?> • <?= e(ad_placement_label($a['placement'])) ?> • <?= e($a['name_ar']??'عام') ?></p>
              <div class="mini muted"><?= e($a['starts_at']?:'بدون بداية') ?> — <?= e($a['ends_at']?:'بدون نهاية') ?> • <?= format_iqd($a['price']) ?></div>
              <div class="pill-row" style="margin-top:10px"><?= status_badge($a['status']) ?><a class="btn small" href="<?= url('admin_ads',['edit'=>$a['id']]) ?>">تعديل</a>
                <?php if(!$visible): ?><form method="post" action="actions.php" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="admin_ad_activate"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="btn small green" type="submit">تفعيل وإظهاره الآن</button></form><?php endif; ?>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
        <?php if(!$ads): ?><div class="empty"><h3>لا توجد إعلانات بعد</h3><p>أضف الإعلان الأول وسيظهر للعملاء فوراً.</p></div><?php endif; ?>
      </div>
    </div>
  </div>
</div></section>
<?php require APP_ROOT.'/views/layout/footer.php'; ?>
