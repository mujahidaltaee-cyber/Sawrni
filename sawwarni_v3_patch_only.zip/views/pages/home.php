<?php
$pageTitle = 'احجز مصورك بسهولة';
$categories = fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order, id');
$ads = fetch_all('SELECT * FROM ads WHERE status="active" AND (placement="home" OR placement="all") AND (starts_at IS NULL OR starts_at <= CURDATE()) AND (ends_at IS NULL OR ends_at >= CURDATE()) ORDER BY id DESC LIMIT 3');
$featured = fetch_all('SELECT pp.*, u.name, u.status, MIN(p.price) AS starting_price, COUNT(DISTINCT p.id) AS package_count, (SELECT pf.file_url FROM portfolios pf WHERE pf.provider_id=pp.id AND pf.media_type="image" ORDER BY pf.id DESC LIMIT 1) AS cover_image FROM provider_profiles pp JOIN users u ON u.id=pp.user_id LEFT JOIN packages p ON p.provider_id=pp.id AND p.status="active" WHERE u.status="active" AND (pp.featured_until IS NOT NULL AND pp.featured_until >= CURDATE() OR pp.verified=1) GROUP BY pp.id ORDER BY pp.featured_until DESC, pp.rating DESC LIMIT 9');
$categoryImages = [
  1=>demo_photo('photo-1689785380577-93f35f4d6bf9'),
  2=>demo_photo('photo-1759054710581-c7745b02cb53'),
  3=>demo_photo('photo-1754373218795-8423da0c33fd'),
  4=>demo_photo('photo-1501386761578-eac5c94b800a'),
  5=>demo_photo('photo-1523275335684-37898b6baf30'),
  6=>demo_photo('photo-1519608487953-e999c86e7455'),
  7=>demo_photo('photo-1516035069371-29a1b244cc32'),
  8=>demo_photo('photo-1502982720700-bfff97f2ecac'),
  9=>demo_photo('photo-1622481176965-cf2ef5993031'),
  10=>demo_photo('photo-1760067537639-0fb475c87657'),
  11=>demo_photo('photo-1501386761578-eac5c94b800a')
];
$inspirationImages = [
  [demo_photo('photo-1689785380577-93f35f4d6bf9',900,1100),'تخرج جماعي'],
  [demo_photo('photo-1744804298565-a25360f791ec',900,1100),'جلسة خطوبة'],
  [demo_photo('photo-1414235077428-338989a2e8c0'),'تصوير مطاعم'],
  [demo_photo('photo-1754373218795-8423da0c33fd'),'درون وعقارات'],
  [demo_photo('photo-1622481176965-cf2ef5993031',900,1100),'سيارات'],
  [demo_photo('photo-1761679296778-7f245d39148d',900,1100),'تصميم داخلي'],
  [demo_photo('photo-1659080910666-68793fa5d2a0',900,1100),'بورتريه تخرج'],
  [demo_photo('photo-1640654438886-2839af1c6287',900,1100),'قصة زفاف'],
  [demo_photo('photo-1504674900247-0877df9cc836'),'Food styling'],
  [demo_photo('photo-1502982720700-bfff97f2ecac'),'كواليس التصوير'],
  [demo_photo('photo-1534528741775-53994a69daeb',900,1100),'Portrait'],
  [demo_photo('photo-1519608487953-e999c86e7455'),'محتوى حضري']
];
$providerFallbacks=['assets/img/demo/avatar-ali.jpg','assets/img/demo/avatar-noor.jpg','assets/img/demo/avatar-omar.jpg','assets/img/demo/avatar-layla.jpg','assets/img/demo/avatar-hassan.jpg','assets/img/demo/avatar-studiox.jpg'];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="hero">
  <div class="container hero-grid">
    <div>
      <span class="eyebrow">أول Marketplace تصوير متكامل</span>
      <h1>كل لحظة تستحق مصوراً مناسباً.</h1>
      <p>اختر بين مصورين موثقين، شاهد الأعمال والأسعار، حدّد الموعد والموقع، ثم تابع الحجز من الطلب حتى التسليم.</p>
      <div class="hero-badges"><span>✓ أسعار واضحة</span><span>✓ مصورون موثقون</span><span>✓ حجز عاجل</span><span>✓ متابعة كاملة</span></div>
      <div class="pill-row">
        <a class="btn primary large" href="<?= url('providers') ?>">اكتشف المصورين</a>
        <a class="btn large" href="<?= url('register', ['type'=>'provider']) ?>">انضم كمقدم خدمة</a>
      </div>
      <div class="trust-row">
        <div class="trust-item"><span class="trust-icon">📸</span><div><strong>خدمات متنوعة</strong><div class="mini muted">تصوير، فيديو، درون</div></div></div>
        <div class="trust-item"><span class="trust-icon">🛡️</span><div><strong>حجز موثوق</strong><div class="mini muted">حالات واضحة ومتابعة</div></div></div>
        <div class="trust-item"><span class="trust-icon">⚡</span><div><strong>طلب عاجل</strong><div class="mini muted">لنفس اليوم</div></div></div>
        <div class="trust-item"><span class="trust-icon">⭐</span><div><strong>تقييمات حقيقية</strong><div class="mini muted">بعد اكتمال الحجز</div></div></div>
      </div>
    </div>
    <div class="hero-visual">
      <img class="hero-main-image" src="<?= e(demo_photo('photo-1502982720700-bfff97f2ecac',1200,900)) ?>" alt="منصة صورني">
      <div class="floating-card floating-rating"><strong>⭐ 4.9 متوسط التقييم</strong><span>مزودون مختارون بعناية</span></div>
      <div class="floating-card floating-booking"><strong>حجز تخرج — بغداد</strong><span>اليوم 5:00 م • مؤكد</span><div class="progress" style="margin-top:10px"><span style="width:76%"></span></div></div>
    </div>
  </div>
</section>

<section class="container">
  <div class="search-card">
    <form class="search-form" method="get" action="index.php">
      <input type="hidden" name="page" value="providers">
      <div class="input-icon"><span>⌕</span><input name="q" placeholder="مصور، درون، ريلز أو اسم الخدمة"></div>
      <select name="category_id"><option value="">كل التصنيفات</option><?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select>
      <input name="city" placeholder="المدينة" value="بغداد">
      <button class="btn primary" type="submit">اعرض النتائج</button>
    </form>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title"><div><span class="eyebrow">اختر تجربتك</span><h2>ما الذي تريد تصويره؟</h2><p class="muted">خدمات منظمة وباقات جاهزة لكل مناسبة.</p></div><a class="btn" href="<?= url('providers') ?>">عرض كل الخدمات</a></div>
    <div class="grid grid-4">
      <?php foreach (array_slice($categories,0,8) as $c): ?>
        <a class="category-card" href="<?= url('providers', ['category_id'=>$c['id']]) ?>">
          <img src="<?= e($categoryImages[(int)$c['id']] ?? 'assets/img/demo/studio.jpg') ?>" alt="<?= e($c['name_ar']) ?>">
          <div class="category-card-content"><div class="category-icon"><?= e($c['icon']) ?></div><h3><?= e($c['name_ar']) ?></h3><p><?= e($c['name_en']) ?></p></div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if ($ads): ?>
<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">Partners</span><h2>عروض من شركائنا</h2></div></div><div class="grid grid-3">
  <?php foreach ($ads as $i=>$ad): ?>
    <a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank"><span class="ad-label">إعلان ممول</span><img src="<?= e($ad['image_url'] ?: ['assets/img/demo/product.jpg','assets/img/demo/wedding.jpg','assets/img/demo/events.jpg'][$i%3]) ?>" alt=""><strong><?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span></a>
  <?php endforeach; ?>
</div></div></section>
<?php endif; ?>


<section class="section inspiration-section">
  <div class="container">
    <div class="section-title"><div><span class="eyebrow">Live portfolio</span><h2>إلهام حقيقي لكل نوع جلسة</h2><p class="muted">صور متنوعة تجعل تجربة التصفح أقرب إلى منصة تصوير حقيقية.</p></div><a class="btn" href="<?= url('providers') ?>">احجز جلسة مشابهة</a></div>
    <div class="inspiration-grid">
      <?php foreach($inspirationImages as $i=>$shot): ?>
        <a class="inspiration-item item-<?= ($i%6)+1 ?>" href="<?= url('providers') ?>">
          <img loading="lazy" src="<?= e($shot[0]) ?>" alt="<?= e($shot[1]) ?>">
          <span><?= e($shot[1]) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title"><div><span class="eyebrow">Top creators</span><h2>مصورون مميزون هذا الأسبوع</h2><p class="muted">ملفات موثقة، أسعار واضحة وأعمال يمكن مشاهدتها قبل الحجز.</p></div><a class="btn" href="<?= url('providers') ?>">كل مقدمي الخدمة</a></div>
    <div class="grid grid-3">
      <?php foreach ($featured as $i=>$p): ?>
        <a class="provider-card" href="<?= url('provider', ['id'=>$p['id']]) ?>">
          <div class="provider-media"><img class="provider-cover" src="<?= e($p['cover_image'] ?: ($p['profile_image'] ?: $providerFallbacks[$i%count($providerFallbacks)])) ?>" alt=""><div class="provider-overlay"><span class="provider-tag"><?= $p['verified'] ? '✓ موثق' : 'مقدم خدمة' ?></span><span class="provider-tag">⭐ <?= e((string)$p['rating']) ?></span></div></div>
          <div class="provider-body"><h3><?= e($p['business_name']) ?></h3><div class="provider-meta"><span>📍 <?= e($p['city']) ?></span><span>•</span><span><?= (int)$p['package_count'] ?> باقات</span></div><div class="provider-actions"><p class="price">من <?= $p['starting_price'] ? format_iqd($p['starting_price']) : '—' ?></p><span class="btn small">عرض الملف</span></div></div>
        </a>
      <?php endforeach; ?>
      <?php if (!$featured): ?><div class="card empty">سيظهر مقدمو الخدمة هنا بعد إضافة البيانات التجريبية.</div><?php endif; ?>
    </div>
  </div>
</section>

<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">Simple flow</span><h2>الحجز بثلاث خطوات فقط</h2></div></div><div class="grid grid-3 steps">
  <div class="step-card"><h3>اكتشف وقارن</h3><p class="muted">اختر نوع الجلسة، المدينة، السعر والمصور حسب الأعمال والتقييم.</p></div>
  <div class="step-card"><h3>حدّد موعدك</h3><p class="muted">اختر الباقة والوقت والموقع، ويمكنك إضافة طلب عاجل لنفس اليوم.</p></div>
  <div class="step-card"><h3>تابع التنفيذ</h3><p class="muted">راقب الحالة، تواصل داخل الحجز، وأرسل تقييمك بعد إكمال الخدمة.</p></div>
</div></div></section>

<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">What people say</span><h2>تجربة تبدو حقيقية من أول يوم</h2></div></div><div class="grid grid-3">
  <div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“لقيت مصور تخرج مناسب للسعر وشفت كل أعماله قبل الحجز. الخطوات واضحة جداً.”</p><div class="testimonial-author"><img src="assets/img/demo/avatar-noor.jpg"><div><strong>نور محمد</strong><div class="mini muted">عميلة تجريبية</div></div></div></div>
  <div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“لوحة المصور رتبت الحجوزات والمواعيد والأرباح بمكان واحد، وهذا أهم شيء بالنسبة لي.”</p><div class="testimonial-author"><img src="assets/img/demo/avatar-ali.jpg"><div><strong>علي المصور</strong><div class="mini muted">مقدم خدمة</div></div></div></div>
  <div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“وجود التقييم، الشكوى، والعمولة المحسوبة تلقائياً يجعل المنصة قابلة للتجربة الفعلية.”</p><div class="testimonial-author"><img src="assets/img/demo/avatar-hassan.jpg"><div><strong>حسن كريم</strong><div class="mini muted">مستخدم تجريبي</div></div></div></div>
</div></div></section>

<section class="section"><div class="container"><div class="cta-banner"><div><span class="eyebrow" style="color:#f2d59f">للمصورين وصناع المحتوى</span><h2>حوّل أعمالك إلى حجوزات منظمة.</h2><p>أنشئ ملفك، أضف الباقات ومعرض الأعمال، استقبل الطلبات وراقب أرباحك من لوحة واحدة.</p><div class="pill-row"><a class="btn gold large" href="<?= url('register',['type'=>'provider']) ?>">انضم كمقدم خدمة</a><a class="btn large" href="<?= url('provider_login') ?>">تسجيل الدخول</a></div></div><img src="<?= e(demo_photo('photo-1516035069371-29a1b244cc32')) ?>" alt="" style="border-radius:24px;height:250px;width:100%;object-fit:cover"></div></div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
