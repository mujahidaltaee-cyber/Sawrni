<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
if (is_logged_in() && has_role('admin')) { redirect('admin_dashboard'); }
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#111318"><title>إدارة صورني</title><link rel="stylesheet" href="assets/css/style.css?v=2.0"></head>
<body class="management-body"><main class="management-login-card">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:15px"><div class="brand"><span class="logo-mark">ص</span><span>صورني</span></div><span class="management-seal">بوابة مخفية</span></div>
  <div style="margin:28px 0 22px"><span class="eyebrow">Management access</span><h1 style="font-size:2.5rem;margin:.2rem 0">مركز الإدارة</h1><p class="muted">الدخول مخصص لإدارة المنصة ولا يظهر ضمن خيارات العملاء أو مقدمي الخدمة.</p></div>
  <?php foreach (flashes() as $flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endforeach; ?>
  <form class="grid-form" method="post" action="actions.php" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="action" value="management_login"><label>اسم المستخدم<div class="input-icon"><span>◉</span><input name="username" value="Mujahid" required autofocus></div></label><label>كلمة المرور<div class="input-icon"><span>●</span><input type="password" name="password" value="123456" required></div></label><button class="btn primary large block" type="submit">دخول الإدارة</button></form>
  <div class="alert warning mini">بيانات الاختبار الافتراضية: Mujahid / 123456. غيّر كلمة المرور قبل استخدام الموقع الحقيقي.</div><a class="subtle-link" href="index.php">← العودة إلى واجهة الموقع</a>
</main></body></html>
