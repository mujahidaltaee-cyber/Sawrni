document.addEventListener('DOMContentLoaded', function () {
  var btn = document.querySelector('[data-toggle-nav]');
  var nav = document.querySelector('[data-nav]');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', nav.classList.contains('open') ? 'true' : 'false');
    });
    document.addEventListener('click', function (event) {
      if (!nav.contains(event.target) && !btn.contains(event.target)) nav.classList.remove('open');
    });
  }

  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (event) {
      if (!window.confirm(el.getAttribute('data-confirm') || 'هل أنت متأكد؟')) event.preventDefault();
    });
  });

  document.querySelectorAll('.alert').forEach(function (alert) {
    alert.setAttribute('role', 'status');
  });

  var urgent = document.querySelector('[data-urgent-checkbox]');
  if (urgent) {
    var base = Number(urgent.getAttribute('data-base') || 0);
    var fee = Number(urgent.getAttribute('data-fee') || 0);
    var totalEl = document.querySelector('[data-booking-total]');
    var commissionEl = document.querySelector('[data-booking-commission]');
    var providerEl = document.querySelector('[data-booking-provider]');
    var percent = Number(urgent.getAttribute('data-commission') || 10);
    var format = function (v) { return Math.round(v).toLocaleString('en-US') + ' IQD'; };
    var update = function () {
      var total = base + (urgent.checked ? fee : 0);
      var baseCommission = Math.round(base * percent / 100);
      var appRevenue = baseCommission + (urgent.checked ? fee : 0);
      var providerRevenue = base - baseCommission;
      if (totalEl) totalEl.textContent = format(total);
      if (commissionEl) commissionEl.textContent = format(appRevenue);
      if (providerEl) providerEl.textContent = format(providerRevenue);
    };
    urgent.addEventListener('change', update);
    update();
  }

  var revealTargets = document.querySelectorAll('.provider-card,.category-card,.step-card,.testimonial,.metric');
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    revealTargets.forEach(function (el) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(14px)';
      el.style.transition = 'opacity .45s ease, transform .45s ease, box-shadow .2s ease';
      observer.observe(el);
    });
  }
});
