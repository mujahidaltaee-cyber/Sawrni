<?php $pageTitle = 'اختيار نوع الدخول'; require APP_ROOT . '/views/layout/header.php'; ?>
<section class="auth-section"><div class="container">
  <div class="auth-heading"><span class="eyebrow">Welcome back</span><h1>اختر الواجهة المناسبة</h1><p class="muted">واجهة مستقلة للعميل، وواجهة عمل متكاملة للمصور. حساب الإدارة يبقى مخفياً.</p></div>
  <div class="grid grid-2 auth-choice-grid">
    <a class="account-choice customer-choice" href="<?= url('customer_login') ?>"><div class="choice-icon">👤</div><div><span class="badge badge-gray">للعملاء</span><h2>دخول العميل</h2><p>اكتشف المصورين، قارن الباقات، أرسل الحجز، تابع الدفع والمحادثة والتقييم.</p><span>فتح واجهة العميل ←</span></div></a>
    <a class="account-choice provider-choice" href="<?= url('provider_login') ?>"><div class="choice-icon">📷</div><div><span class="badge badge-gray">للمصورين</span><h2>دخول مقدم الخدمة</h2><p>أدر الملف، الباقات، معرض الأعمال، التوفر، الحجوزات والأرباح.</p><span>فتح لوحة مقدم الخدمة ←</span></div></a>
  </div>
  <div class="card" style="max-width:1000px;margin:22px auto 0;text-align:center"><strong>بيانات العرض التجريبي</strong><p class="muted">العميل: customer@sawwarni.test — المصور: provider@sawwarni.test — كلمة المرور: 123456</p></div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
