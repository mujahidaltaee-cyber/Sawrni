<?php
$pageTitle = 'احجز مصورك بسهولة';
$categories = fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order, id');
$ads = fetch_all('SELECT * FROM ads WHERE status="active" AND (placement="home" OR placement="all") AND (starts_at IS NULL OR starts_at <= CURDATE()) AND (ends_at IS NULL OR ends_at >= CURDATE()) ORDER BY id DESC LIMIT 3');
$featured = fetch_all('SELECT pp.*, u.name, u.status, MIN(p.price) AS starting_price, COUNT(DISTINCT p.id) AS package_count FROM provider_profiles pp JOIN users u ON u.id=pp.user_id LEFT JOIN packages p ON p.provider_id=pp.id AND p.status="active" WHERE u.status="active" AND (pp.featured_until IS NOT NULL AND pp.featured_until >= CURDATE() OR pp.verified=1) GROUP BY pp.id ORDER BY pp.featured_until DESC, pp.rating DESC LIMIT 6');
$categoryImages = [
  1=>'assets/img/demo/graduation.jpg',2=>'assets/img/demo/wedding.jpg',3=>'assets/img/demo/drone.jpg',4=>'assets/img/demo/events.jpg',
  5=>'assets/img/demo/product.jpg',6=>'assets/img/demo/reels.jpg',7=>'assets/img/demo/studio.jpg',8=>'assets/img/demo/editing.jpg',
  9=>'assets/img/demo/food.jpg',10=>'assets/img/demo/car.jpg',11=>'assets/img/demo/realestate.jpg'
];
$providerFallbacks=['assets/img/demo/avatar-ali.jpg','assets/img/demo/avatar-noor.jpg','assets/img/demo/avatar-omar.jpg','assets/img/demo/avatar-layla.jpg','assets/img/demo/avatar-hassan.jpg','assets/img/demo/avatar-studiox.jpg'];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="hero">
  <div class="container hero-grid">
    <div>
      <span class="eyebrow">أول Marketplace تصوير متكامل</span>
      <h1>كل لحظة تستحق مصوراً مناسباً.</h1>
      <p>اختر بين مصورين موثقين، شاهد الأعمال والأسعار، حدّد الموعد والموقع، ثم تابع الحجز من الطلب حتى التسليم.</p>
      <div class="hero-badges"><span>✓ أسعار واضحة</span><span>✓ مصورون موثقون</span><span>✓ حجز عاجل</span><span>✓ متابعة كاملة</span></div>
      <div class="pill-row">
        <a class="btn primary large" href="<?= url('providers') ?>">اكتشف المصورين</a>
        <a class="btn large" href="<?= url('register', ['type'=>'provider']) ?>">انضم كمقدم خدمة</a>
      </div>
      <div class="trust-row">
        <div class="trust-item"><span class="trust-icon">📸</span><div><strong>خدمات متنوعة</strong><div class="mini muted">تصوير، فيديو، درون</div></div></div>
        <div class="trust-item"><span class="trust-icon">🛡️</span><div><strong>حجز موثوق</strong><div class="mini muted">حالات واضحة ومتابعة</div></div></div>
        <div class="trust-item"><span class="trust-icon">⚡</span><div><strong>طلب عاجل</strong><div class="mini muted">لنفس اليوم</div></div></div>
        <div class="trust-item"><span class="trust-icon">⭐</span><div><strong>تقييمات حقيقية</strong><div class="mini muted">بعد اكتمال الحجز</div></div></div>
      </div>
    </div>
    <div class="hero-visual">
      <img class="hero-main-image" src="assets/img/demo/hero-camera.jpg" alt="منصة صورني">
      <div class="floating-card floating-rating"><strong>⭐ 4.9 متوسط التقييم</strong><span>مزودون مختارون بعناية</span></div>
      <div class="floating-card floating-booking"><strong>حجز تخرج — بغداد</strong><span>اليوم 5:00 م • مؤكد</span><div class="progress" style="margin-top:10px"><span style="width:76%"></span></div></div>
    </div>
  </div>
</section>

<section class="container">
  <div class="search-card">
    <form class="search-form" method="get" action="index.php">
      <input type="hidden" name="page" value="providers">
      <div class="input-icon"><span>⌕</span><input name="q" placeholder="مصور، درون، ريلز أو اسم الخدمة"></div>
      <select name="category_id"><option value="">كل التصنيفات</option><?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select>
      <input name="city" placeholder="المدينة" value="بغداد">
      <button class="btn primary" type="submit">اعرض النتائج</button>
    </form>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title"><div><span class="eyebrow">اختر تجربتك</span><h2>ما الذي تريد تصويره؟</h2><p class="muted">خدمات منظمة وباقات جاهزة لكل مناسبة.</p></div><a class="btn" href="<?= url('providers') ?>">عرض كل الخدمات</a></div>
    <div class="grid grid-4">
      <?php foreach (array_slice($categories,0,8) as $c): ?>
        <a class="category-card" href="<?= url('providers', ['category_id'=>$c['id']]) ?>">
          <img src="<?= e($categoryImages[(int)$c['id']] ?? 'assets/img/demo/studio.jpg') ?>" alt="<?= e($c['name_ar']) ?>">
          <div class="category-card-content"><div class="category-icon"><?= e($c['icon']) ?></div><h3><?= e($c['name_ar']) ?></h3><p><?= e($c['name_en']) ?></p></div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if ($ads): ?>
<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">Partners</span><h2>عروض من شركائنا</h2></div></div><div class="grid grid-3">
  <?php foreach ($ads as $i=>$ad): ?>
    <a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank"><span class="ad-label">إعلان ممول</span><img src="<?= e($ad['image_url'] ?: ['assets/img/demo/product.jpg','assets/img/demo/wedding.jpg','assets/img/demo/events.jpg'][$i%3]) ?>" alt=""><strong><?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span></a>
  <?php endforeach; ?>
</div></div></section>
<?php endif; ?>

<section class="section">
  <div class="container">
    <div class="section-title"><div><span class="eyebrow">Top creators</span><h2>مصورون مميزون هذا الأسبوع</h2><p class="muted">ملفات موثقة، أسعار واضحة وأعمال يمكن مشاهدتها قبل الحجز.</p></div><a class="btn" href="<?= url('providers') ?>">كل مقدمي الخدمة</a></div>
    <div class="grid grid-3">
      <?php foreach ($featured as $i=>$p): ?>
        <a class="provider-card" href="<?= url('provider', ['id'=>$p['id']]) ?>">
          <div class="provider-media"><img class="provider-cover" src="<?= e($p['profile_image'] ?: $providerFallbacks[$i%count($providerFallbacks)]) ?>" alt=""><div class="provider-overlay"><span class="provider-tag"><?= $p['verified'] ? '✓ موثق' : 'مقدم خدمة' ?></span><span class="provider-tag">⭐ <?= e((string)$p['rating']) ?></span></div></div>
          <div class="provider-body"><h3><?= e($p['business_name']) ?></h3><div class="provider-meta"><span>📍 <?= e($p['city']) ?></span><span>•</span><span><?= (int)$p['package_count'] ?> باقات</span></div><div class="provider-actions"><p class="price">من <?= $p['starting_price'] ? format_iqd($p['starting_price']) : '—' ?></p><span class="btn small">عرض الملف</span></div></div>
        </a>
      <?php endforeach; ?>
      <?php if (!$featured): ?><div class="card empty">سيظهر مقدمو الخدمة هنا بعد إضافة البيانات التجريبية.</div><?php endif; ?>
    </div>
  </div>
</section>

<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">Simple flow</span><h2>الحجز بثلاث خطوات فقط</h2></div></div><div class="grid grid-3 steps">
  <div class="step-card"><h3>اكتشف وقارن</h3><p class="muted">اختر نوع الجلسة، المدينة، السعر والمصور حسب الأعمال والتقييم.</p></div>
  <div class="step-card"><h3>حدّد موعدك</h3><p class="muted">اختر الباقة والوقت والموقع، ويمكنك إضافة طلب عاجل لنفس اليوم.</p></div>
  <div class="step-card"><h3>تابع التنفيذ</h3><p class="muted">راقب الحالة، تواصل داخل الحجز، وأرسل تقييمك بعد إكمال الخدمة.</p></div>
</div></div></section>

<section class="section"><div class="container"><div class="section-title"><div><span class="eyebrow">What people say</span><h2>تجربة تبدو حقيقية من أول يوم</h2></div></div><div class="grid grid-3">
  <div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“لقيت مصور تخرج مناسب للسعر وشفت كل أعماله قبل الحجز. الخطوات واضحة جداً.”</p><div class="testimonial-author"><img src="assets/img/demo/avatar-noor.jpg"><div><strong>نور محمد</strong><div class="mini muted">عميلة تجريبية</div></div></div></div>
  <div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“لوحة المصور رتبت الحجوزات والمواعيد والأرباح بمكان واحد، وهذا أهم شيء بالنسبة لي.”</p><div class="testimonial-author"><img src="assets/img/demo/avatar-ali.jpg"><div><strong>علي المصور</strong><div class="mini muted">مقدم خدمة</div></div></div></div>
  <div class="testimonial"><div class="testimonial-stars">★★★★★</div><p>“وجود التقييم، الشكوى، والعمولة المحسوبة تلقائياً يجعل المنصة قابلة للتجربة الفعلية.”</p><div class="testimonial-author"><img src="assets/img/demo/avatar-hassan.jpg"><div><strong>حسن كريم</strong><div class="mini muted">مستخدم تجريبي</div></div></div></div>
</div></div></section>

<section class="section"><div class="container"><div class="cta-banner"><div><span class="eyebrow" style="color:#f2d59f">للمصورين وصناع المحتوى</span><h2>حوّل أعمالك إلى حجوزات منظمة.</h2><p>أنشئ ملفك، أضف الباقات ومعرض الأعمال، استقبل الطلبات وراقب أرباحك من لوحة واحدة.</p><div class="pill-row"><a class="btn gold large" href="<?= url('register',['type'=>'provider']) ?>">انضم كمقدم خدمة</a><a class="btn large" href="<?= url('provider_login') ?>">تسجيل الدخول</a></div></div><img src="assets/img/demo/studio.jpg" alt="" style="border-radius:24px;height:250px;width:100%;object-fit:cover"></div></div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
