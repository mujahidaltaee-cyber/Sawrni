<?php $pageTitle = 'دخول مقدم الخدمة'; require APP_ROOT . '/views/layout/header.php'; ?>
<section class="auth-section"><div class="container auth-narrow"><div class="auth-layout">
  <div class="auth-visual"><img src="assets/img/demo/studio.jpg" alt=""><div class="brand"><span class="logo-mark">ص</span><span>صورني Pro</span></div><div><span class="badge badge-gray">واجهة مقدم الخدمة</span><h2>حوّل أعمالك إلى حجوزات حقيقية.</h2><p>أدر ملفك، الباقات، المواعيد، الأرباح والظهور المميز من لوحة احترافية.</p></div></div>
  <div class="auth-form-panel"><span class="eyebrow">Provider login</span><h1 style="font-size:2.5rem;margin:.2rem 0">دخول المصور</h1><p class="muted">ادخل إلى لوحة عملك لإدارة الطلبات والخدمات.</p>
    <form class="grid-form" method="post" action="actions.php"><?= csrf_field() ?><input type="hidden" name="action" value="provider_login"><label>البريد الإلكتروني<div class="input-icon"><span>✉</span><input type="email" name="email" required autocomplete="email" value="provider@sawwarni.test"></div></label><label>كلمة المرور<div class="input-icon"><span>●</span><input type="password" name="password" required autocomplete="current-password" value="123456"></div></label><button class="btn provider-btn large block" type="submit">دخول مقدم الخدمة</button></form>
    <div class="auth-footer">لم تنضم بعد؟ <a href="<?= url('register',['type'=>'provider']) ?>">إنشاء حساب مقدم خدمة</a></div><div class="divider"></div><a class="btn block" href="<?= url('customer_login') ?>">أنا عميل</a>
  </div>
</div></div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
