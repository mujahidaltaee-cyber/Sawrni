<?php
$pageTitle = 'المصورون والخدمات';
$q = trim($_GET['q'] ?? '');
$city = trim($_GET['city'] ?? '');
$cat = (int)($_GET['category_id'] ?? 0);
$categories = fetch_all('SELECT * FROM categories WHERE status="active" ORDER BY sort_order, id');
$ads = fetch_all('SELECT * FROM ads WHERE status="active" AND (placement="category" OR placement="all") AND (starts_at IS NULL OR starts_at <= CURDATE()) AND (ends_at IS NULL OR ends_at >= CURDATE()) ORDER BY id DESC LIMIT 2');
$params = [];
$sql = 'SELECT pp.*, u.name, MIN(p.price) AS starting_price, COUNT(DISTINCT p.id) AS package_count
        FROM provider_profiles pp
        JOIN users u ON u.id=pp.user_id
        LEFT JOIN packages p ON p.provider_id=pp.id AND p.status="active"
        LEFT JOIN provider_categories pc ON pc.provider_id=pp.id
        WHERE u.status="active"';
if ($q !== '') { $sql .= ' AND (pp.business_name LIKE ? OR pp.bio LIKE ? OR pp.equipment LIKE ?)'; $params[]="%$q%"; $params[]="%$q%"; $params[]="%$q%"; }
if ($city !== '') { $sql .= ' AND pp.city LIKE ?'; $params[]="%$city%"; }
if ($cat > 0) { $sql .= ' AND (pc.category_id=? OR p.category_id=?)'; $params[]=$cat; $params[]=$cat; }
$sql .= ' GROUP BY pp.id ORDER BY CASE WHEN pp.featured_until >= CURDATE() THEN 0 ELSE 1 END, pp.verified DESC, pp.rating DESC, pp.total_bookings DESC';
$providers = fetch_all($sql, $params);
$fallbacks=['assets/img/demo/avatar-ali.jpg','assets/img/demo/avatar-noor.jpg','assets/img/demo/avatar-omar.jpg','assets/img/demo/avatar-layla.jpg','assets/img/demo/avatar-hassan.jpg','assets/img/demo/avatar-studiox.jpg'];
require APP_ROOT . '/views/layout/header.php';
?>
<section class="section"><div class="container">
  <div class="section-title"><div><span class="eyebrow">Explore creators</span><h1 style="font-size:clamp(2.2rem,4vw,4rem)">اختر المصور المناسب للحظة المناسبة.</h1><p class="muted">قارن الباقات، الأعمال، التقييمات وأوقات التوفر قبل إرسال الطلب.</p></div><span class="role-chip customer-chip"><?= count($providers) ?> نتيجة متاحة</span></div>
  <div class="search-card">
    <form class="search-form" method="get">
      <input type="hidden" name="page" value="providers">
      <div class="input-icon"><span>⌕</span><input name="q" value="<?= e($q) ?>" placeholder="اسم المصور أو نوع الخدمة"></div>
      <select name="category_id"><option value="">كل التصنيفات</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $cat===(int)$c['id']?'selected':'' ?>><?= e($c['icon'].' '.$c['name_ar']) ?></option><?php endforeach; ?></select>
      <input name="city" value="<?= e($city) ?>" placeholder="بغداد أو المدينة">
      <button class="btn primary">تطبيق البحث</button>
    </form>
    <div class="pill-row" style="margin-top:14px">
      <a class="badge badge-gray" href="<?= url('providers') ?>">الكل</a>
      <?php foreach(array_slice($categories,0,6) as $c): ?><a class="badge <?= $cat===(int)$c['id']?'badge-yellow':'badge-gray' ?>" href="<?= url('providers',['category_id'=>$c['id'],'city'=>$city]) ?>"><?= e($c['icon'].' '.$c['name_ar']) ?></a><?php endforeach; ?>
    </div>
  </div>

  <?php if($ads): ?><div class="grid grid-2" style="margin-top:20px"><?php foreach($ads as $i=>$ad): ?><a class="ad-card" href="<?= e($ad['target_url'] ?: '#') ?>" target="_blank"><span class="ad-label">إعلان ممول</span><img src="<?= e($ad['image_url'] ?: ($i?'assets/img/demo/events.jpg':'assets/img/demo/product.jpg')) ?>" alt=""><strong><?= e($ad['title']) ?></strong><br><span class="muted"><?= e($ad['advertiser_name']) ?></span></a><?php endforeach; ?></div><?php endif; ?>

  <div class="grid grid-3" style="margin-top:24px">
    <?php foreach($providers as $i=>$p): ?>
      <a class="provider-card" href="<?= url('provider',['id'=>$p['id']]) ?>">
        <div class="provider-media"><img class="provider-cover" src="<?= e($p['profile_image'] ?: $fallbacks[$i%count($fallbacks)]) ?>" alt="<?= e($p['business_name']) ?>"><div class="provider-overlay"><span class="provider-tag"><?= $p['verified']?'✓ موثق':'جديد' ?></span><?php if($p['featured_until'] && $p['featured_until'] >= date('Y-m-d')): ?><span class="provider-tag">★ مميز</span><?php endif; ?></div></div>
        <div class="provider-body">
          <h3><?= e($p['business_name']) ?></h3>
          <div class="provider-meta"><span>📍 <?= e($p['city']) ?><?= $p['area']?' — '.e($p['area']):'' ?></span><span>⭐ <?= e((string)$p['rating']) ?></span></div>
          <p class="muted"><?= e(short_text($p['bio'] ?? '', 112)) ?></p>
          <div class="provider-actions"><div><span class="mini muted">يبدأ من</span><p class="price" style="margin:0"><?= $p['starting_price'] ? format_iqd($p['starting_price']) : '—' ?></p></div><span class="badge badge-gray"><?= (int)$p['package_count'] ?> باقات</span></div>
        </div>
      </a>
    <?php endforeach; ?>
    <?php if(!$providers): ?><div class="card empty" style="grid-column:1/-1"><h3>لم نجد نتائج مطابقة</h3><p>جرّب إزالة بعض الفلاتر أو البحث باسم خدمة مختلف.</p><a class="btn" href="<?= url('providers') ?>">إعادة ضبط البحث</a></div><?php endif; ?>
  </div>
</div></section>
<?php require APP_ROOT . '/views/layout/footer.php'; ?>
