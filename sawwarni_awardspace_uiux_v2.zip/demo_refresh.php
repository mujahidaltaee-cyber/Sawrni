<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
require_role('admin');
require_method_post();
verify_csrf();
require_once __DIR__ . '/app/demo_seed.php';
try {
    $result=seed_full_demo(db());
    flash('success','تم تحديث البيانات التجريبية: '.$result['providers'].' مقدمي خدمة، '.$result['bookings'].' حجوزات، وصور وإعلانات تجريبية.');
} catch(Throwable $e){
    flash('danger','تعذر تحديث البيانات التجريبية: '.$e->getMessage());
}
redirect('admin_dashboard');
