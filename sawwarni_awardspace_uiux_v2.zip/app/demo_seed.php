<?php
declare(strict_types=1);

function seed_full_demo(PDO $pdo): array
{
    $password = password_hash('123456', PASSWORD_DEFAULT);
    $now = date('Y-m-d');
    $nextMonth = date('Y-m-d', strtotime('+30 days'));

    $pdo->exec("INSERT IGNORE INTO categories (id,name_ar,name_en,icon,status,sort_order) VALUES
      (9,'تصوير سيارات','Automotive Photography','🚘','active',9),
      (10,'تصوير عقارات','Real Estate Photography','🏠','active',10),
      (11,'تغطية فعاليات','Event Coverage','🎤','active',11)");

    $customers = [
        ['عميل تجريبي','customer@sawwarni.test','07700000001'],
        ['نور محمد','noor.customer@sawwarni.test','07700000011'],
        ['حسن كريم','hassan.customer@sawwarni.test','07700000012'],
    ];
    $uStmt=$pdo->prepare('INSERT INTO users (name,email,phone,password_hash,role,status) VALUES (?,?,?,? ,"customer","active") ON DUPLICATE KEY UPDATE name=VALUES(name),phone=VALUES(phone),password_hash=VALUES(password_hash),status="active"');
    foreach($customers as $c){$uStmt->execute([$c[0],$c[1],$c[2],$password]);}

    $providers = [
      ['علي المصور','provider@sawwarni.test','07700000002','Ali Photography','تصوير تخرج، مناسبات، ريلز وتصوير منتجات داخل بغداد. خبرة في الإضاءة الطبيعية وصناعة القصص البصرية.','بغداد','المنصور','Canon R6، عدسة 24-70، إضاءة متنقلة، DJI Gimbal','assets/img/demo/avatar-ali.jpg',4.90,[1,4,5,6]],
      ['نور كريم','noor.provider@sawwarni.test','07700000003','Noor Visuals','جلسات نسائية، ستوديو، منتجات وتغطية مناسبات بأسلوب هادئ وألوان احترافية.','بغداد','الكرادة','Sony A7 IV، 50mm، Softbox، Mac Studio','assets/img/demo/avatar-noor.jpg',4.85,[2,4,5,7]],
      ['عمر سعد','omar.provider@sawwarni.test','07700000004','Omar Drone Works','تصوير درون سينمائي للفعاليات والعقارات والمشاريع التجارية مع مونتاج احترافي.','بغداد','الجادرية','DJI Mavic 3 Pro، DJI Air 3، ND Filters','assets/img/demo/avatar-omar.jpg',4.80,[3,6,10,11]],
      ['ليلى أحمد','layla.provider@sawwarni.test','07700000005','Layla Stories','تغطية أعراس وخطوبة وجلسات تخرج بأسلوب وثائقي دافئ وتسليم منظم.','بغداد','زيونة','Canon R5، 35mm، 85mm، Flash Kit','assets/img/demo/avatar-layla.jpg',4.95,[1,2,4]],
      ['حسن ميديا','hassan.provider@sawwarni.test','07700000006','Hassan Media','تصوير سيارات، مطاعم، منتجات وفيديوهات إعلانية قصيرة للمشاريع.','بغداد','اليرموك','Sony FX3، Sigma Art، Car Rig، LED Kit','assets/img/demo/avatar-hassan.jpg',4.70,[5,6,9]],
      ['ستوديو إكس','studio.provider@sawwarni.test','07700000007','Studio X Baghdad','استوديو مجهز للبورتريه، المنتجات، الهوية البصرية والمحتوى التجاري.','بغداد','العرصات','Full studio lighting، Backdrops، Product Table','assets/img/demo/avatar-studiox.jpg',4.88,[5,7,8]],
    ];
    $pUser=$pdo->prepare('INSERT INTO users (name,email,phone,password_hash,role,status) VALUES (?,?,?,? ,"provider","active") ON DUPLICATE KEY UPDATE name=VALUES(name),phone=VALUES(phone),password_hash=VALUES(password_hash),status="active"');
    $profileStmt=$pdo->prepare('INSERT INTO provider_profiles (user_id,business_name,bio,city,area,instagram_url,profile_image,equipment,verified,rating,total_bookings,subscription_status,featured_until) VALUES (?,?,?,?,?,?,?, ?,1,?,?,"active",?) ON DUPLICATE KEY UPDATE business_name=VALUES(business_name),bio=VALUES(bio),city=VALUES(city),area=VALUES(area),profile_image=VALUES(profile_image),equipment=VALUES(equipment),verified=1,rating=VALUES(rating),subscription_status="active",featured_until=VALUES(featured_until)');
    $providerIds=[];
    foreach($providers as $index=>$p){
        $pUser->execute([$p[0],$p[1],$p[2],$password]);
        $uid=(int)$pdo->query("SELECT id FROM users WHERE email=".$pdo->quote($p[1])." LIMIT 1")->fetchColumn();
        $profileStmt->execute([$uid,$p[3],$p[4],$p[5],$p[6],'',$p[8],$p[7],$p[9],12+$index*7,$nextMonth]);
        $pid=(int)$pdo->query('SELECT id FROM provider_profiles WHERE user_id='.$uid)->fetchColumn();
        $providerIds[]=$pid;
        $pdo->prepare('DELETE FROM provider_categories WHERE provider_id=?')->execute([$pid]);
        $pc=$pdo->prepare('INSERT IGNORE INTO provider_categories (provider_id,category_id) VALUES (?,?)');
        foreach($p[10] as $cid){$pc->execute([$pid,$cid]);}
        $pdo->prepare('DELETE FROM availability WHERE provider_id=?')->execute([$pid]);
        $av=$pdo->prepare('INSERT INTO availability (provider_id,day_of_week,start_time,end_time,is_available) VALUES (?,?,?,?,1)');
        foreach([0,1,2,3,4,6] as $day){$av->execute([$pid,$day,'09:00:00','20:00:00']);}
    }

    $packageDefs = [
      0=>[[1,'باقة تخرج أساسية','ساعة تصوير، 20 صورة معدلة، موقع واحد.',75000,60,3,0,0,0],[1,'باقة تخرج بريميوم','ساعتان، 35 صورة، Reel قصير وموقعان.',150000,120,4,0,1,1],[6,'Reel للمشاريع','تصوير ومونتاج فيديو عمودي احترافي.',125000,90,4,0,1,1]],
      1=>[[7,'جلسة ستوديو ناعمة','45 دقيقة، 12 صورة معدلة، خلفيتان.',85000,45,3,0,0,0],[2,'تغطية خطوبة','3 ساعات تصوير وصور مختارة معدلة.',300000,180,7,0,1,1],[5,'تصوير منتجات مصغر','10 منتجات بخلفية موحدة.',140000,120,5,0,0,0]],
      2=>[[3,'درون أساسي','30 دقيقة طيران وفيديو خام مختار.',120000,45,3,1,1,0],[3,'درون سينمائي','تغطية متعددة اللقطات وفيديو نهائي.',250000,120,6,1,1,1],[10,'عقار من الجو','صور وفيديو للعقار والمحيط.',180000,90,4,1,1,0]],
      3=>[[2,'Wedding Story','تغطية 6 ساعات، صور وفيديو Highlight.',650000,360,14,0,1,1],[1,'تخرج Editorial','جلسة ساعتين بتوجيه كامل وتعديل متقدم.',190000,120,5,0,1,1],[4,'عيد ميلاد','ساعتان وتغطية تفاصيل المناسبة.',170000,120,4,0,1,0]],
      4=>[[9,'جلسة سيارة','موقعان، لقطات خارجية وتفاصيل.',160000,120,5,0,1,0],[5,'مطعم Social Pack','20 صورة و3 فيديوهات قصيرة.',280000,180,7,0,1,1],[6,'إعلان قصير','فيديو تجاري 30-45 ثانية.',350000,240,10,0,1,1]],
      5=>[[7,'Portrait Pro','ساعة ستوديو و15 صورة Retouched.',110000,60,4,0,0,0],[5,'Product Premium','20 منتج، إضاءة احترافية وتعديل.',300000,240,7,0,0,1],[8,'Editing Pack','تعديل 30 صورة أو فيديو قصير.',90000,60,3,0,1,0]],
    ];
    $packStmt=$pdo->prepare('INSERT INTO packages (provider_id,category_id,title,description,price,duration_minutes,delivery_days,includes_drone,includes_video,is_premium,status) VALUES (?,?,?,?,?,?,?,?,?,? ,"active")');
    $packUpdate=$pdo->prepare('UPDATE packages SET category_id=?,description=?,price=?,duration_minutes=?,delivery_days=?,includes_drone=?,includes_video=?,is_premium=?,status="active" WHERE id=?');
    foreach($providerIds as $i=>$pid){
        foreach($packageDefs[$i] as $pack){
            $find=$pdo->prepare('SELECT id FROM packages WHERE provider_id=? AND title=? LIMIT 1');
            $find->execute([$pid,$pack[1]]);
            $existingId=(int)($find->fetchColumn() ?: 0);
            if($existingId){
                $packUpdate->execute([$pack[0],$pack[2],$pack[3],$pack[4],$pack[5],$pack[6],$pack[7],$pack[8],$existingId]);
            }else{
                $packStmt->execute(array_merge([$pid],$pack));
            }
        }
    }

    $portfolioMap=[
      0=>[['graduation.jpg','جلسة تخرج في بغداد'],['reels.jpg','Reel لمشروع محلي'],['product.jpg','تصوير منتج تجاري'],['events.jpg','تغطية مناسبة']],
      1=>[['studio.jpg','بورتريه ستوديو'],['wedding.jpg','جلسة خطوبة'],['food.jpg','تصوير مطعم'],['product.jpg','منتجات تجميل']],
      2=>[['drone.jpg','لقطة جوية سينمائية'],['realestate.jpg','تصوير عقاري'],['events.jpg','تغطية فعالية'],['reels.jpg','مونتاج فيديو جوي']],
      3=>[['wedding.jpg','قصة زفاف'],['graduation.jpg','جلسة تخرج Editorial'],['events.jpg','تفاصيل مناسبة'],['studio.jpg','بورتريه']],
      4=>[['car.jpg','جلسة سيارة'],['food.jpg','مطعم ومحتوى اجتماعي'],['product.jpg','حملة منتج'],['reels.jpg','إعلان قصير']],
      5=>[['studio.jpg','Portrait Pro'],['product.jpg','Product Studio'],['editing.jpg','Color grading'],['food.jpg','Still life']],
    ];
    $portStmt=$pdo->prepare('INSERT INTO portfolios (provider_id,category_id,media_type,file_url,caption) VALUES (?,NULL,"image",?,?)');
    foreach($providerIds as $i=>$pid){$pdo->prepare('DELETE FROM portfolios WHERE provider_id=?')->execute([$pid]);foreach($portfolioMap[$i] as $item){$portStmt->execute([$pid,'assets/img/demo/'.$item[0],$item[1]]);}}

    $customerId=(int)$pdo->query("SELECT id FROM users WHERE email='customer@sawwarni.test'")->fetchColumn();
    $noorId=(int)$pdo->query("SELECT id FROM users WHERE email='noor.customer@sawwarni.test'")->fetchColumn();
    $packageIdByTitle=function(int $providerId,string $title) use ($pdo): int {
        $st=$pdo->prepare('SELECT id FROM packages WHERE provider_id=? AND title=? LIMIT 1');
        $st->execute([$providerId,$title]);
        return (int)$st->fetchColumn();
    };
    $bookings=[
      ['DEMO-001',$customerId,$providerIds[0],$packageIdByTitle($providerIds[0],'باقة تخرج أساسية'),date('Y-m-d',strtotime('+4 days')),'16:00:00','المنصور - بغداد',0,75000,'confirmed','paid'],
      ['DEMO-002',$noorId,$providerIds[3],$packageIdByTitle($providerIds[3],'Wedding Story'),date('Y-m-d',strtotime('-8 days')),'17:30:00','الجادرية - بغداد',0,650000,'completed','provider_paid'],
      ['DEMO-003',$customerId,$providerIds[2],$packageIdByTitle($providerIds[2],'درون أساسي'),date('Y-m-d',strtotime('+1 day')),'14:00:00','أبو نؤاس - بغداد',1,130000,'accepted','deposit_paid'],
      ['DEMO-004',$noorId,$providerIds[4],$packageIdByTitle($providerIds[4],'جلسة سيارة'),date('Y-m-d',strtotime('-18 days')),'11:00:00','اليرموك - بغداد',0,160000,'completed','provider_paid'],
      ['DEMO-005',$customerId,$providerIds[5],$packageIdByTitle($providerIds[5],'Portrait Pro'),date('Y-m-d',strtotime('+9 days')),'10:30:00','ستوديو إكس - العرصات',0,110000,'pending','unpaid'],
    ];
    $bStmt=$pdo->prepare('INSERT INTO bookings (booking_code,customer_id,provider_id,package_id,category_id,booking_date,start_time,end_time,location,customer_notes,urgent,urgent_fee_amount,total_price,app_commission,provider_amount,status,payment_status) SELECT ?,?,?,?,?,?,?,ADDTIME(?,"01:00:00"),?,"حجز تجريبي لإظهار سير العمل",?,?,?,?,?,?,? FROM packages WHERE id=? ON DUPLICATE KEY UPDATE booking_date=VALUES(booking_date),status=VALUES(status),payment_status=VALUES(payment_status),location=VALUES(location)');
    foreach($bookings as $b){
        $catId=(int)$pdo->query('SELECT category_id FROM packages WHERE id='.(int)$b[3])->fetchColumn();
        $urgentFee=$b[7]?10000:0;
        $base=$b[8]-$urgentFee;
        $baseCommission=(int)round($base*.10);
        $commission=$baseCommission+$urgentFee;
        $providerAmount=$base-$baseCommission;
        $bStmt->execute([$b[0],$b[1],$b[2],$b[3],$catId,$b[4],$b[5],$b[5],$b[6],$b[7],$urgentFee,$b[8],$commission,$providerAmount,$b[9],$b[10],$b[3]]);
    }

    $paidBookings=$pdo->query("SELECT id,customer_id,provider_id,total_price,app_commission,provider_amount,payment_status FROM bookings WHERE booking_code IN ('DEMO-001','DEMO-002','DEMO-003','DEMO-004')")->fetchAll(PDO::FETCH_ASSOC);
    foreach($paidBookings as $pb){
        $payStatus=in_array($pb['payment_status'],['paid','provider_paid'],true)?'confirmed':'pending';
        $amount=$pb['payment_status']==='deposit_paid'?25000:$pb['total_price'];
        $pdo->prepare('INSERT INTO payments (booking_id,customer_id,provider_id,amount_paid,payment_method,transaction_reference,app_commission,provider_amount,status) SELECT ?,?,?,?,"manual_deposit",?, ?,?,? WHERE NOT EXISTS (SELECT 1 FROM payments WHERE booking_id=?)')->execute([(int)$pb['id'],(int)$pb['customer_id'],(int)$pb['provider_id'],$amount,'DEMO-PAY-'.$pb['id'],$pb['app_commission'],$pb['provider_amount'],$payStatus,(int)$pb['id']]);
        $pdo->prepare('INSERT INTO booking_messages (booking_id,sender_id,message) SELECT ?,?,? WHERE NOT EXISTS (SELECT 1 FROM booking_messages WHERE booking_id=? AND sender_id=? AND message=?)')->execute([(int)$pb['id'],(int)$pb['customer_id'],'مرحباً، أريد التأكيد على تفاصيل وموقع الجلسة.',(int)$pb['id'],(int)$pb['customer_id'],'مرحباً، أريد التأكيد على تفاصيل وموقع الجلسة.']);
        $providerUserId=(int)$pdo->query('SELECT user_id FROM provider_profiles WHERE id='.(int)$pb['provider_id'])->fetchColumn();
        $pdo->prepare('INSERT INTO booking_messages (booking_id,sender_id,message) SELECT ?,?,? WHERE NOT EXISTS (SELECT 1 FROM booking_messages WHERE booking_id=? AND sender_id=? AND message=?)')->execute([(int)$pb['id'],$providerUserId,'تم استلام الطلب، الموعد متاح وسأتواصل معك داخل الحجز.',(int)$pb['id'],$providerUserId,'تم استلام الطلب، الموعد متاح وسأتواصل معك داخل الحجز.']);
    }

    $completed=$pdo->query("SELECT id,customer_id,provider_id FROM bookings WHERE booking_code IN ('DEMO-002','DEMO-004')")->fetchAll(PDO::FETCH_ASSOC);
    foreach($completed as $idx=>$b){$pdo->prepare('INSERT INTO reviews (booking_id,customer_id,provider_id,rating,comment) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE rating=VALUES(rating),comment=VALUES(comment)')->execute([(int)$b['id'],(int)$b['customer_id'],(int)$b['provider_id'],5,$idx===0?'التعامل راقٍ والنتائج أجمل من المتوقع، والتسليم كان منظم.':'التصوير احترافي جداً، خصوصاً زوايا السيارة والتعديل النهائي.']);}

    foreach($providerIds as $pid){$pdo->prepare('INSERT INTO provider_subscriptions (provider_id,plan_name,price,starts_at,ends_at,status,notes) SELECT ?,"Pro",50000,?,?,"active","اشتراك تجريبي" WHERE NOT EXISTS (SELECT 1 FROM provider_subscriptions WHERE provider_id=? AND status="active")')->execute([$pid,$now,$nextMonth,$pid]);}
    foreach(array_slice($providerIds,0,4) as $pid){$pdo->prepare('INSERT INTO featured_providers (provider_id,city,starts_at,ends_at,amount_paid,status) SELECT ?,"بغداد",?,?,75000,"active" WHERE NOT EXISTS (SELECT 1 FROM featured_providers WHERE provider_id=? AND status="active")')->execute([$pid,$now,$nextMonth,$pid]);}

    $ads=[
      ['Baghdad Camera House','خصم 15% على تأجير معدات الإضاءة','assets/img/demo/product.jpg','home',250000],
      ['Graduation Gowns Iraq','باقات روب التخرج والتصوير الجماعي','assets/img/demo/graduation.jpg','category',180000],
      ['Royal Events Hall','احجز القاعة واحصل على عرض تصوير خاص','assets/img/demo/wedding.jpg','booking',300000],
    ];
    $adStmt=$pdo->prepare('INSERT INTO ads (advertiser_name,title,image_url,target_url,city,starts_at,ends_at,price,placement,status) SELECT ?,?,?,"#","بغداد",?,?,?,?,"active" WHERE NOT EXISTS (SELECT 1 FROM ads WHERE advertiser_name=? AND title=?)');
    foreach($ads as $a){$adStmt->execute([$a[0],$a[1],$a[2],$now,$nextMonth,$a[4],$a[3],$a[0],$a[1]]);}

    return ['providers'=>count($providers),'customers'=>count($customers),'bookings'=>count($bookings),'ads'=>count($ads)];
}
