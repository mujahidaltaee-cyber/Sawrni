صورني — تحديث الهيدر والشعار V4.1

هذا التحديث يحتوي فقط على:
- views/layout/header.php
- assets/css/style.css
- assets/img/brand/sawwarni-header-logo.webp
- assets/img/brand/sawwarni-header-logo.png

لا يحتوي على قاعدة البيانات أو app/config.php أو أي حسابات أو حجوزات.
ارفع محتويات هذا المجلد فوق الملفات الحالية مع الحفاظ على نفس المسارات.

بعد الرفع افتح:
https://sawrni-demo.atwebpages.com/?v=4.1
